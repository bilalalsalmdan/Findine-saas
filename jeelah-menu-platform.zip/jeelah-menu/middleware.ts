import { NextResponse } from "next/server";
import type { NextRequest } from "next/server";
import { jwtVerify } from "jose";

const PUBLIC_ROUTES = [
  "/",
  "/pricing",
  "/solutions",
  "/features",
  "/about",
  "/contact",
  "/blog",
  "/enterprise",
  "/legal",
  "/login",
  "/register",
  "/forgot-password",
  "/menu",
];

const ADMIN_ROUTES = ["/admin"];
const DASHBOARD_ROUTES = ["/restaurant"];

function isPublicRoute(pathname: string): boolean {
  return PUBLIC_ROUTES.some(
    (route) => pathname === route || pathname.startsWith(`${route}/`)
  );
}

export async function middleware(request: NextRequest) {
  const { pathname } = request.nextUrl;
  const response = NextResponse.next();

  // ━━━ 1. i18n: Detect language ━━━
  const langCookie = request.cookies.get("lang")?.value;
  const acceptLang = request.headers.get("accept-language");
  const detectedLang =
    langCookie || (acceptLang?.startsWith("ar") ? "ar" : "en");
  response.headers.set("x-lang", detectedLang);

  // ━━━ 2. Skip auth for public routes and API webhooks ━━━
  if (
    isPublicRoute(pathname) ||
    pathname.startsWith("/api/webhooks") ||
    pathname.startsWith("/_next") ||
    pathname.includes(".")
  ) {
    return response;
  }

  // ━━━ 3. Auth check ━━━
  const token = request.cookies.get("auth-token")?.value;

  if (!token) {
    const loginUrl = new URL("/login", request.url);
    loginUrl.searchParams.set("redirect", pathname);
    return NextResponse.redirect(loginUrl);
  }

  try {
    const secret = new TextEncoder().encode(process.env.JWT_SECRET!);
    const { payload } = await jwtVerify(token, secret);

    const userRole = payload.role as string;
    const restaurantId = payload.restaurantId as string;

    // ━━━ 4. RBAC enforcement ━━━
    if (pathname.startsWith("/admin") && userRole !== "super_admin") {
      return NextResponse.redirect(new URL("/restaurant", request.url));
    }

    if (
      pathname.startsWith("/restaurant") &&
      !["restaurant_owner", "restaurant_staff", "super_admin"].includes(userRole)
    ) {
      return NextResponse.redirect(new URL("/login", request.url));
    }

    // ━━━ 5. Tenant isolation: inject restaurant_id header ━━━
    if (restaurantId) {
      response.headers.set("x-restaurant-id", restaurantId);
    }

    response.headers.set("x-user-id", payload.sub as string);
    response.headers.set("x-user-role", userRole);

    return response;
  } catch {
    // Token invalid or expired → redirect to login
    const loginUrl = new URL("/login", request.url);
    loginUrl.searchParams.set("redirect", pathname);
    const redirectResponse = NextResponse.redirect(loginUrl);
    redirectResponse.cookies.delete("auth-token");
    return redirectResponse;
  }
}

export const config = {
  matcher: [
    /*
     * Match all request paths except:
     * - _next/static (static files)
     * - _next/image (image optimization files)
     * - favicon.ico (favicon)
     * - public folder
     */
    "/((?!_next/static|_next/image|favicon.ico|images|fonts).*)",
  ],
};
