import type { Config } from "tailwindcss";

const config: Config = {
  content: ["./src/**/*.{ts,tsx}"],
  darkMode: "class",
  theme: {
    extend: {
      // ━━━ COLORS (FineDine forensic extraction) ━━━
      colors: {
        brand: {
          DEFAULT: "#E6034B",
          50: "#FFF0F3",
          100: "#FFE0E8",
          200: "#FFC1D1",
          300: "#FF92AD",
          400: "#FF5480",
          500: "#E6034B",
          600: "#D10043",
          700: "#AF003A",
          800: "#920036",
          900: "#7B0033",
          950: "#460018",
        },
        violet: {
          DEFAULT: "#7C3AED",
          50: "#F5F3FF",
          100: "#EDE9FE",
          200: "#DDD6FE",
          300: "#C4B5FD",
          400: "#A78BFA",
          500: "#7C3AED",
          600: "#7C3AED",
          700: "#6D28D9",
          800: "#5B21B6",
          900: "#4C1D95",
        },
        gray: {
          50: "#F9FAFB",
          100: "#F3F4F6",
          200: "#E5E7EB",
          300: "#D1D5DB",
          400: "#9CA3AF",
          500: "#6B7280",
          600: "#4B5563",
          700: "#374151",
          800: "#1F2937",
          900: "#111827",
          950: "#030712",
        },
      },

      // ━━━ TYPOGRAPHY ━━━
      fontFamily: {
        sans: ["DM Sans", "system-ui", "sans-serif"],
        display: ["Playfair Display", "Georgia", "serif"],
      },
      fontSize: {
        "display-xl": ["4.5rem", { lineHeight: "1.1", letterSpacing: "-0.02em" }],
        "display-lg": ["3.75rem", { lineHeight: "1.1", letterSpacing: "-0.02em" }],
        "display-md": ["3rem", { lineHeight: "1.15", letterSpacing: "-0.01em" }],
        "display-sm": ["2.25rem", { lineHeight: "1.2", letterSpacing: "-0.01em" }],
        "heading-lg": ["1.875rem", { lineHeight: "1.3" }],
        "heading-md": ["1.5rem", { lineHeight: "1.35" }],
        "heading-sm": ["1.25rem", { lineHeight: "1.4" }],
        "body-lg": ["1.125rem", { lineHeight: "1.6" }],
        "body-md": ["1rem", { lineHeight: "1.6" }],
        "body-sm": ["0.875rem", { lineHeight: "1.5" }],
        "body-xs": ["0.75rem", { lineHeight: "1.5" }],
      },

      // ━━━ SPACING (4px base grid) ━━━
      spacing: {
        "18": "4.5rem",
        "22": "5.5rem",
        "26": "6.5rem",
        "30": "7.5rem",
        "34": "8.5rem",
        "38": "9.5rem",
      },

      // ━━━ BORDER RADIUS ━━━
      borderRadius: {
        sm: "0.375rem",
        md: "0.5rem",
        lg: "0.75rem",
        xl: "1.25rem",
        "2xl": "1.5rem",
        pill: "9999px",
      },

      // ━━━ SHADOWS ━━━
      boxShadow: {
        "soft-sm": "0 1px 2px rgba(0, 0, 0, 0.05)",
        "soft-md": "0 4px 6px -1px rgba(0, 0, 0, 0.07), 0 2px 4px -2px rgba(0, 0, 0, 0.05)",
        "soft-lg": "0 10px 15px -3px rgba(0, 0, 0, 0.08), 0 4px 6px -4px rgba(0, 0, 0, 0.03)",
        "soft-xl": "0 20px 25px -5px rgba(0, 0, 0, 0.08), 0 8px 10px -6px rgba(0, 0, 0, 0.03)",
        glow: "0 0 40px rgba(230, 3, 75, 0.15)",
        "glow-violet": "0 0 40px rgba(124, 58, 237, 0.15)",
      },

      // ━━━ ANIMATIONS ━━━
      keyframes: {
        "scroll-left": {
          "0%": { transform: "translateX(0)" },
          "100%": { transform: "translateX(-50%)" },
        },
        "fade-in-up": {
          "0%": { opacity: "0", transform: "translateY(20px)" },
          "100%": { opacity: "1", transform: "translateY(0)" },
        },
        "gradient-shift": {
          "0%, 100%": { backgroundPosition: "0% 50%" },
          "50%": { backgroundPosition: "100% 50%" },
        },
        "blob-float": {
          "0%, 100%": { transform: "translate(0, 0) scale(1)" },
          "33%": { transform: "translate(30px, -50px) scale(1.1)" },
          "66%": { transform: "translate(-20px, 20px) scale(0.9)" },
        },
        shimmer: {
          "0%": { backgroundPosition: "-200% 0" },
          "100%": { backgroundPosition: "200% 0" },
        },
      },
      animation: {
        "scroll-left": "scroll-left 30s linear infinite",
        "fade-in-up": "fade-in-up 0.6s ease-out",
        "gradient-shift": "gradient-shift 4s ease infinite",
        "blob-float": "blob-float 8s ease-in-out infinite",
        shimmer: "shimmer 2s linear infinite",
      },

      // ━━━ BACKGROUND IMAGE ━━━
      backgroundImage: {
        "brand-gradient": "linear-gradient(135deg, #E6034B, #7C3AED)",
        "brand-gradient-r": "linear-gradient(135deg, #7C3AED, #E6034B)",
        "dark-gradient": "radial-gradient(ellipse at top, #1F2937 0%, #111827 70%)",
        "mesh-gradient": "radial-gradient(at 40% 20%, rgba(230,3,75,0.08) 0px, transparent 50%), radial-gradient(at 80% 0%, rgba(124,58,237,0.06) 0px, transparent 50%)",
      },

      // ━━━ TRANSITIONS ━━━
      transitionDuration: {
        "200": "200ms",
        "300": "300ms",
      },
    },
  },
  plugins: [
    require("@tailwindcss/typography"),
    require("@tailwindcss/forms"),
  ],
};

export default config;
