"use client";

import { useState, useEffect } from "react";
import Link from "next/link";
import { cn } from "@/lib/utils";
import { marketingNav } from "@/config/navigation";
import { Menu, X, ChevronDown } from "lucide-react";

export function Navbar() {
  const [scrolled, setScrolled] = useState(false);
  const [mobileOpen, setMobileOpen] = useState(false);
  const [openDropdown, setOpenDropdown] = useState<string | null>(null);

  useEffect(() => {
    const handleScroll = () => setScrolled(window.scrollY > 20);
    window.addEventListener("scroll", handleScroll);
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  return (
    <header
      className={cn(
        "fixed top-0 left-0 right-0 z-50 transition-all duration-300",
        scrolled
          ? "bg-white/90 backdrop-blur-xl border-b border-gray-200/50 shadow-soft-sm"
          : "bg-transparent"
      )}
    >
      <nav className="container-wide flex items-center justify-between h-16 lg:h-20">
        {/* Logo */}
        <Link href="/" className="flex items-center gap-2.5">
          <div className="w-9 h-9 rounded-xl bg-brand-gradient flex items-center justify-center">
            <span className="text-white font-bold text-lg">J</span>
          </div>
          <span
            className={cn(
              "text-lg font-bold transition-colors",
              scrolled ? "text-gray-900" : "text-white"
            )}
          >
            Jeelah Menu
          </span>
        </Link>

        {/* Desktop Nav */}
        <div className="hidden lg:flex items-center gap-1">
          {marketingNav.map((item) => (
            <div
              key={item.href}
              className="relative"
              onMouseEnter={() =>
                item.children && setOpenDropdown(item.title)
              }
              onMouseLeave={() => setOpenDropdown(null)}
            >
              <Link
                href={item.href}
                className={cn(
                  "flex items-center gap-1 px-4 py-2 text-sm font-medium rounded-lg transition-colors",
                  scrolled
                    ? "text-gray-600 hover:text-gray-900 hover:bg-gray-100"
                    : "text-white/80 hover:text-white hover:bg-white/10"
                )}
              >
                {item.title}
                {item.children && <ChevronDown className="w-3.5 h-3.5" />}
              </Link>

              {/* Dropdown */}
              {item.children && openDropdown === item.title && (
                <div className="absolute top-full left-0 mt-1 w-52 bg-white rounded-xl shadow-soft-xl border border-gray-200 py-2 animate-fade-in-up">
                  {item.children.map((child) => (
                    <Link
                      key={child.href}
                      href={child.href}
                      className="block px-4 py-2.5 text-sm text-gray-600 hover:text-brand hover:bg-brand/5 transition-colors"
                    >
                      {child.title}
                    </Link>
                  ))}
                </div>
              )}
            </div>
          ))}
        </div>

        {/* CTA Buttons */}
        <div className="hidden lg:flex items-center gap-3">
          <Link
            href="/login"
            className={cn(
              "px-4 py-2 text-sm font-medium rounded-pill transition-colors",
              scrolled
                ? "text-gray-700 hover:text-gray-900"
                : "text-white/80 hover:text-white"
            )}
          >
            Log In
          </Link>
          <Link
            href="/register"
            className="btn-brand text-sm px-5 py-2.5"
          >
            Start Free Trial
          </Link>
        </div>

        {/* Mobile menu button */}
        <button
          onClick={() => setMobileOpen(!mobileOpen)}
          className="lg:hidden p-2 rounded-lg hover:bg-white/10"
          aria-label="Toggle menu"
        >
          {mobileOpen ? (
            <X
              className={cn(
                "w-6 h-6",
                scrolled ? "text-gray-900" : "text-white"
              )}
            />
          ) : (
            <Menu
              className={cn(
                "w-6 h-6",
                scrolled ? "text-gray-900" : "text-white"
              )}
            />
          )}
        </button>
      </nav>

      {/* Mobile Menu */}
      {mobileOpen && (
        <div className="lg:hidden fixed inset-0 top-16 bg-white z-40 overflow-y-auto">
          <div className="p-6 space-y-4">
            {marketingNav.map((item) => (
              <div key={item.href}>
                <Link
                  href={item.href}
                  className="block py-3 text-lg font-medium text-gray-900"
                  onClick={() => setMobileOpen(false)}
                >
                  {item.title}
                </Link>
                {item.children && (
                  <div className="pl-4 space-y-2">
                    {item.children.map((child) => (
                      <Link
                        key={child.href}
                        href={child.href}
                        className="block py-2 text-sm text-gray-600"
                        onClick={() => setMobileOpen(false)}
                      >
                        {child.title}
                      </Link>
                    ))}
                  </div>
                )}
              </div>
            ))}
            <div className="pt-4 space-y-3 border-t border-gray-200">
              <Link
                href="/login"
                className="block w-full text-center py-3 text-gray-700 font-medium border border-gray-300 rounded-pill"
              >
                Log In
              </Link>
              <Link
                href="/register"
                className="block w-full text-center btn-brand py-3"
              >
                Start Free Trial
              </Link>
            </div>
          </div>
        </div>
      )}
    </header>
  );
}
