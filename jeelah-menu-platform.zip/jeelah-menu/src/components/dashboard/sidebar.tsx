"use client";

import { useState } from "react";
import Link from "next/link";
import { usePathname } from "next/navigation";
import { cn } from "@/lib/utils";
import { restaurantNav, adminNav } from "@/config/navigation";
import {
  ChevronLeft,
  LogOut,
  Bell,
  HelpCircle,
  Moon,
  Sun,
} from "lucide-react";

interface SidebarProps {
  variant?: "restaurant" | "admin";
  restaurantName?: string;
  userName?: string;
  userAvatar?: string;
}

export function Sidebar({
  variant = "restaurant",
  restaurantName = "My Restaurant",
  userName = "Owner",
  userAvatar,
}: SidebarProps) {
  const pathname = usePathname();
  const [collapsed, setCollapsed] = useState(false);
  const navItems = variant === "admin" ? adminNav : restaurantNav;

  return (
    <aside
      className={cn(
        "fixed left-0 top-0 z-40 h-screen bg-white border-r border-gray-200 transition-all duration-300 flex flex-col",
        collapsed ? "w-[72px]" : "w-[260px]"
      )}
    >
      {/* Logo / Brand */}
      <div className="flex items-center gap-3 px-4 h-16 border-b border-gray-100 shrink-0">
        <div className="w-8 h-8 rounded-lg bg-brand-gradient flex items-center justify-center shrink-0">
          <span className="text-white font-bold text-sm">J</span>
        </div>
        {!collapsed && (
          <div className="flex flex-col min-w-0">
            <span className="text-sm font-bold text-gray-900 truncate">
              Jeelah Menu
            </span>
            <span className="text-xs text-gray-500 truncate">
              {restaurantName}
            </span>
          </div>
        )}
        <button
          onClick={() => setCollapsed(!collapsed)}
          className="ml-auto p-1.5 rounded-lg hover:bg-gray-100 transition-colors shrink-0"
          aria-label={collapsed ? "Expand sidebar" : "Collapse sidebar"}
        >
          <ChevronLeft
            className={cn(
              "w-4 h-4 text-gray-400 transition-transform",
              collapsed && "rotate-180"
            )}
          />
        </button>
      </div>

      {/* Navigation */}
      <nav className="flex-1 overflow-y-auto py-4 px-3 space-y-1">
        {navItems.map((item) => {
          const isActive =
            pathname === item.href ||
            (item.href !== "/restaurant" &&
              item.href !== "/admin" &&
              pathname.startsWith(item.href));

          const Icon = item.icon;

          return (
            <Link
              key={item.href}
              href={item.href}
              className={cn(
                "sidebar-link group relative",
                isActive && "active",
                collapsed && "justify-center px-0"
              )}
              title={collapsed ? item.title : undefined}
            >
              {Icon && (
                <Icon
                  className={cn(
                    "w-5 h-5 shrink-0",
                    isActive ? "text-brand" : "text-gray-400 group-hover:text-gray-600"
                  )}
                />
              )}
              {!collapsed && (
                <>
                  <span className="truncate">{item.title}</span>
                  {item.badge && (
                    <span className="ml-auto badge-brand text-[10px] px-2 py-0.5">
                      {item.badge}
                    </span>
                  )}
                </>
              )}
              {/* Tooltip for collapsed state */}
              {collapsed && (
                <span className="absolute left-full ml-2 px-2 py-1 rounded-md bg-gray-900 text-white text-xs whitespace-nowrap opacity-0 group-hover:opacity-100 transition-opacity pointer-events-none z-50">
                  {item.title}
                </span>
              )}
            </Link>
          );
        })}
      </nav>

      {/* Bottom section */}
      <div className="border-t border-gray-100 p-3 space-y-1 shrink-0">
        <button
          className={cn(
            "sidebar-link w-full",
            collapsed && "justify-center px-0"
          )}
        >
          <HelpCircle className="w-5 h-5 text-gray-400 shrink-0" />
          {!collapsed && <span>Help & Support</span>}
        </button>
        <button
          className={cn(
            "sidebar-link w-full text-red-500 hover:text-red-600 hover:bg-red-50",
            collapsed && "justify-center px-0"
          )}
        >
          <LogOut className="w-5 h-5 shrink-0" />
          {!collapsed && <span>Log Out</span>}
        </button>
      </div>
    </aside>
  );
}
