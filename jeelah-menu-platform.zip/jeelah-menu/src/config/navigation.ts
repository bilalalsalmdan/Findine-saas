import {
  LayoutDashboard,
  UtensilsCrossed,
  ListTree,
  FolderOpen,
  QrCode,
  ShoppingCart,
  BarChart3,
  Users,
  Settings,
  CreditCard,
  Plug,
  Building2,
  FileText,
  Shield,
} from "lucide-react";

export interface NavItem {
  title: string;
  href: string;
  icon?: any;
  badge?: string;
  children?: NavItem[];
}

// ━━━ Marketing Navbar ━━━

export const marketingNav: NavItem[] = [
  {
    title: "Solutions",
    href: "/solutions",
    children: [
      { title: "QR Menu", href: "/solutions/qr-menu" },
      { title: "Tablet Menu", href: "/solutions/tablet-menu" },
      { title: "Online Ordering", href: "/solutions/ordering" },
      { title: "Payments", href: "/solutions/payments" },
    ],
  },
  {
    title: "Features",
    href: "/features",
    children: [
      { title: "AI Menu Builder", href: "/features/ai-menu" },
      { title: "AI Website Builder", href: "/features/ai-website" },
      { title: "Analytics", href: "/features/analytics" },
      { title: "Reservations", href: "/features/reservations" },
    ],
  },
  { title: "Pricing", href: "/pricing" },
  { title: "Enterprise", href: "/enterprise" },
  { title: "Blog", href: "/blog" },
];

// ━━━ Restaurant Dashboard Sidebar ━━━

export const restaurantNav: NavItem[] = [
  { title: "Dashboard", href: "/restaurant", icon: LayoutDashboard },
  { title: "Menu", href: "/restaurant/menu", icon: UtensilsCrossed },
  { title: "Dishes", href: "/restaurant/dishes", icon: ListTree },
  { title: "Categories", href: "/restaurant/categories", icon: FolderOpen },
  { title: "QR Codes", href: "/restaurant/qr", icon: QrCode },
  {
    title: "Orders",
    href: "/restaurant/orders",
    icon: ShoppingCart,
    badge: "Live",
  },
  { title: "Analytics", href: "/restaurant/analytics", icon: BarChart3 },
  { title: "Staff", href: "/restaurant/staff", icon: Users },
  { title: "Settings", href: "/restaurant/settings", icon: Settings },
  { title: "Billing", href: "/restaurant/billing", icon: CreditCard },
  { title: "Integrations", href: "/restaurant/integrations", icon: Plug },
];

// ━━━ Admin Dashboard Sidebar ━━━

export const adminNav: NavItem[] = [
  { title: "Dashboard", href: "/admin", icon: LayoutDashboard },
  { title: "Restaurants", href: "/admin/restaurants", icon: Building2 },
  { title: "Plans", href: "/admin/plans", icon: CreditCard },
  { title: "Analytics", href: "/admin/analytics", icon: BarChart3 },
  { title: "Users", href: "/admin/users", icon: Users },
  { title: "Content", href: "/admin/content", icon: FileText },
  { title: "Settings", href: "/admin/settings", icon: Shield },
];

// ━━━ Footer Links ━━━

export const footerNav = {
  product: [
    { title: "QR Menu", href: "/solutions/qr-menu" },
    { title: "Tablet Menu", href: "/solutions/tablet-menu" },
    { title: "Online Ordering", href: "/solutions/ordering" },
    { title: "Payments", href: "/solutions/payments" },
    { title: "AI Features", href: "/features" },
    { title: "Pricing", href: "/pricing" },
  ],
  company: [
    { title: "About", href: "/about" },
    { title: "Blog", href: "/blog" },
    { title: "Careers", href: "/careers" },
    { title: "Contact", href: "/contact" },
    { title: "Enterprise", href: "/enterprise" },
  ],
  legal: [
    { title: "Privacy Policy", href: "/legal/privacy" },
    { title: "Terms of Service", href: "/legal/terms" },
    { title: "Cookie Policy", href: "/legal/cookies" },
    { title: "DPA", href: "/legal/dpa" },
  ],
  support: [
    { title: "Help Center", href: "/help" },
    { title: "Documentation", href: "/docs" },
    { title: "API Reference", href: "/docs/api" },
    { title: "Status", href: "https://status.jeelahmenu.com" },
  ],
};
