export const siteConfig = {
  name: "Jeelah Menu",
  nameAr: "جيلة منيو",
  tagline: "AI-Powered Digital Menus for Restaurants",
  taglineAr: "قوائم رقمية ذكية للمطاعم",
  description:
    "Transform your restaurant with AI-powered digital menus, QR ordering, and smart analytics.",
  url: "https://jeelahmenu.com",
  ogImage: "https://jeelahmenu.com/images/og-image.png",
  links: {
    twitter: "https://twitter.com/jeelahmenu",
    instagram: "https://instagram.com/jeelahmenu",
    linkedin: "https://linkedin.com/company/jeelahmenu",
  },
  creator: "Jeelah Menu",
  email: "hello@jeelahmenu.com",
  supportEmail: "support@jeelahmenu.com",
};
