export interface PlanFeature {
  name: string;
  included: boolean;
  limit?: string;
}

export interface Plan {
  id: string;
  name: string;
  tier: "base" | "premium" | "enterprise";
  description: string;
  priceMonthly: number;
  priceYearly: number;
  currency: string;
  features: PlanFeature[];
  highlighted?: boolean;
  cta: string;
  stripePriceIdMonthly?: string;
  stripePriceIdYearly?: string;
}

export const PLANS: Plan[] = [
  {
    id: "base",
    name: "Base",
    tier: "base",
    description: "Everything you need to get started with digital menus.",
    priceMonthly: 39,
    priceYearly: 31,
    currency: "USD",
    cta: "Start Free Trial",
    features: [
      { name: "Digital QR Menu", included: true },
      { name: "Unlimited menu items", included: true },
      { name: "Basic analytics", included: true },
      { name: "1 QR code design", included: true },
      { name: "Email support", included: true },
      { name: "2 languages", included: true, limit: "2" },
      { name: "Tablet menu", included: false },
      { name: "AI descriptions", included: false },
      { name: "Online ordering", included: false },
      { name: "Custom branding", included: false },
      { name: "Priority support", included: false },
      { name: "API access", included: false },
    ],
  },
  {
    id: "premium",
    name: "Premium",
    tier: "premium",
    description: "Advanced features for growing restaurants.",
    priceMonthly: 119,
    priceYearly: 95,
    currency: "USD",
    highlighted: true,
    cta: "Start Free Trial",
    features: [
      { name: "Digital QR Menu", included: true },
      { name: "Unlimited menu items", included: true },
      { name: "Advanced analytics", included: true },
      { name: "Unlimited QR designs", included: true },
      { name: "Priority support", included: true },
      { name: "40 languages", included: true, limit: "40" },
      { name: "Tablet menu", included: true },
      { name: "AI descriptions", included: true },
      { name: "Online ordering", included: true },
      { name: "Custom branding", included: true },
      { name: "CRM & feedback", included: true },
      { name: "API access", included: false },
    ],
  },
  {
    id: "enterprise",
    name: "Enterprise",
    tier: "enterprise",
    description: "Full platform for hotel chains and multi-venue operations.",
    priceMonthly: 0, // Custom pricing
    priceYearly: 0,
    currency: "USD",
    cta: "Contact Sales",
    features: [
      { name: "Digital QR Menu", included: true },
      { name: "Unlimited everything", included: true },
      { name: "Custom analytics", included: true },
      { name: "Unlimited QR designs", included: true },
      { name: "Dedicated account manager", included: true },
      { name: "40+ languages", included: true, limit: "40+" },
      { name: "Tablet menu + kiosk", included: true },
      { name: "AI descriptions", included: true },
      { name: "Online ordering + delivery", included: true },
      { name: "White-label branding", included: true },
      { name: "POS integration", included: true },
      { name: "Full API access", included: true },
    ],
  },
];

export function getPlan(tier: string): Plan | undefined {
  return PLANS.find((p) => p.tier === tier);
}

export function getPlanPrice(
  tier: string,
  interval: "monthly" | "yearly"
): number {
  const plan = getPlan(tier);
  if (!plan) return 0;
  return interval === "yearly" ? plan.priceYearly : plan.priceMonthly;
}
