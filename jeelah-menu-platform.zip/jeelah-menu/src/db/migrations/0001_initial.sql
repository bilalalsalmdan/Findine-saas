-- Jeelah Menu — Initial Migration
-- PostgreSQL 15+
-- Multi-tenant SaaS schema

BEGIN;

-- ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
-- ENUMS
-- ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

CREATE TYPE user_role AS ENUM ('super_admin', 'restaurant_owner', 'restaurant_staff', 'customer');
CREATE TYPE subscription_status AS ENUM ('trialing', 'active', 'past_due', 'canceled', 'unpaid');
CREATE TYPE plan_tier AS ENUM ('base', 'premium', 'enterprise');
CREATE TYPE order_status AS ENUM ('pending', 'confirmed', 'preparing', 'ready', 'delivered', 'canceled');
CREATE TYPE payment_status AS ENUM ('pending', 'paid', 'failed', 'refunded');
CREATE TYPE menu_type AS ENUM ('dine_in', 'takeaway', 'delivery', 'room_service');
CREATE TYPE asset_type AS ENUM ('dish_image', 'logo', 'banner', 'gallery', 'menu_background');

-- ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
-- RESTAURANTS
-- ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

CREATE TABLE restaurants (
  id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  name            VARCHAR(255) NOT NULL,
  slug            VARCHAR(255) NOT NULL,
  description     TEXT,
  description_ar  TEXT,
  logo            VARCHAR(500),
  banner          VARCHAR(500),
  phone           VARCHAR(20),
  email           VARCHAR(255),
  website         VARCHAR(500),
  address         TEXT,
  city            VARCHAR(100),
  country         VARCHAR(100) DEFAULT 'JO',
  latitude        DECIMAL(10, 7),
  longitude       DECIMAL(10, 7),
  currency        VARCHAR(3) NOT NULL DEFAULT 'JOD',
  timezone        VARCHAR(50) NOT NULL DEFAULT 'Asia/Amman',
  default_language VARCHAR(5) NOT NULL DEFAULT 'ar',
  supported_languages JSONB NOT NULL DEFAULT '["ar", "en"]',
  theme           JSONB DEFAULT '{"primaryColor": "#E6034B", "fontFamily": "DM Sans", "borderRadius": "1.25rem", "darkMode": false}',
  settings        JSONB DEFAULT '{"showPrices": true, "showCalories": true, "showAllergens": true, "allowOrdering": true, "allowFeedback": true, "showRecommendations": true, "taxRate": 0.16, "serviceCharge": 0}',
  social_links    JSONB DEFAULT '{}',
  is_active       BOOLEAN NOT NULL DEFAULT true,
  created_at      TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at      TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE UNIQUE INDEX restaurants_slug_idx ON restaurants(slug);
CREATE INDEX restaurants_city_idx ON restaurants(city);
CREATE INDEX restaurants_active_idx ON restaurants(is_active);

-- ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
-- USERS
-- ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

CREATE TABLE users (
  id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  email           VARCHAR(255) NOT NULL,
  password_hash   VARCHAR(255) NOT NULL,
  name            VARCHAR(255) NOT NULL,
  name_ar         VARCHAR(255),
  phone           VARCHAR(20),
  avatar          VARCHAR(500),
  role            user_role NOT NULL DEFAULT 'restaurant_owner',
  restaurant_id   UUID REFERENCES restaurants(id) ON DELETE CASCADE,
  email_verified  BOOLEAN NOT NULL DEFAULT false,
  last_login_at   TIMESTAMPTZ,
  is_active       BOOLEAN NOT NULL DEFAULT true,
  created_at      TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at      TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE UNIQUE INDEX users_email_idx ON users(email);
CREATE INDEX users_restaurant_idx ON users(restaurant_id);
CREATE INDEX users_role_idx ON users(role);

-- ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
-- REFRESH TOKENS
-- ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

CREATE TABLE refresh_tokens (
  id          UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id     UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  token       VARCHAR(500) NOT NULL,
  expires_at  TIMESTAMPTZ NOT NULL,
  created_at  TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE UNIQUE INDEX refresh_tokens_token_idx ON refresh_tokens(token);
CREATE INDEX refresh_tokens_user_idx ON refresh_tokens(user_id);
CREATE INDEX refresh_tokens_expires_idx ON refresh_tokens(expires_at);

-- ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
-- MENUS
-- ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

CREATE TABLE menus (
  id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  restaurant_id   UUID NOT NULL REFERENCES restaurants(id) ON DELETE CASCADE,
  name            VARCHAR(255) NOT NULL,
  name_ar         VARCHAR(255),
  description     TEXT,
  description_ar  TEXT,
  type            menu_type NOT NULL DEFAULT 'dine_in',
  is_active       BOOLEAN NOT NULL DEFAULT true,
  is_default      BOOLEAN NOT NULL DEFAULT false,
  sort_order      INTEGER NOT NULL DEFAULT 0,
  available_from  VARCHAR(5),
  available_to    VARCHAR(5),
  available_days  JSONB DEFAULT '[0,1,2,3,4,5,6]',
  created_at      TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at      TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX menus_restaurant_idx ON menus(restaurant_id);
CREATE INDEX menus_active_idx ON menus(is_active);
CREATE INDEX menus_sort_idx ON menus(restaurant_id, sort_order);

-- ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
-- CATEGORIES
-- ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

CREATE TABLE categories (
  id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  restaurant_id   UUID NOT NULL REFERENCES restaurants(id) ON DELETE CASCADE,
  menu_id         UUID NOT NULL REFERENCES menus(id) ON DELETE CASCADE,
  name            VARCHAR(255) NOT NULL,
  name_ar         VARCHAR(255),
  description     TEXT,
  description_ar  TEXT,
  image           VARCHAR(500),
  icon            VARCHAR(50),
  sort_order      INTEGER NOT NULL DEFAULT 0,
  is_active       BOOLEAN NOT NULL DEFAULT true,
  created_at      TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at      TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX categories_restaurant_idx ON categories(restaurant_id);
CREATE INDEX categories_menu_idx ON categories(menu_id);
CREATE INDEX categories_sort_idx ON categories(menu_id, sort_order);

-- ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
-- DISHES
-- ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

CREATE TABLE dishes (
  id                UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  restaurant_id     UUID NOT NULL REFERENCES restaurants(id) ON DELETE CASCADE,
  category_id       UUID NOT NULL REFERENCES categories(id) ON DELETE CASCADE,
  name              VARCHAR(255) NOT NULL,
  name_ar           VARCHAR(255),
  description       TEXT,
  description_ar    TEXT,
  price             DECIMAL(10, 2) NOT NULL,
  compare_at_price  DECIMAL(10, 2),
  image             VARCHAR(500),
  images            JSONB DEFAULT '[]',
  calories          INTEGER,
  prep_time         INTEGER,
  spice_level       INTEGER,
  allergens         JSONB DEFAULT '[]',
  dietary_tags      JSONB DEFAULT '[]',
  nutrition_info    JSONB DEFAULT '{}',
  ingredients       JSONB DEFAULT '[]',
  variants          JSONB DEFAULT '[]',
  addons            JSONB DEFAULT '[]',
  is_available      BOOLEAN NOT NULL DEFAULT true,
  is_featured       BOOLEAN NOT NULL DEFAULT false,
  is_new            BOOLEAN NOT NULL DEFAULT false,
  sort_order        INTEGER NOT NULL DEFAULT 0,
  ai_generated      BOOLEAN DEFAULT false,
  created_at        TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at        TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX dishes_restaurant_idx ON dishes(restaurant_id);
CREATE INDEX dishes_category_idx ON dishes(category_id);
CREATE INDEX dishes_available_idx ON dishes(restaurant_id, is_available);
CREATE INDEX dishes_featured_idx ON dishes(restaurant_id, is_featured);
CREATE INDEX dishes_sort_idx ON dishes(category_id, sort_order);
CREATE INDEX dishes_price_idx ON dishes(restaurant_id, price);

-- ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
-- ORDERS
-- ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

CREATE TABLE orders (
  id                UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  order_number      SERIAL,
  restaurant_id     UUID NOT NULL REFERENCES restaurants(id) ON DELETE CASCADE,
  customer_name     VARCHAR(255),
  customer_phone    VARCHAR(20),
  customer_email    VARCHAR(255),
  table_number      VARCHAR(20),
  room_number       VARCHAR(20),
  type              menu_type NOT NULL DEFAULT 'dine_in',
  status            order_status NOT NULL DEFAULT 'pending',
  payment_status    payment_status NOT NULL DEFAULT 'pending',
  payment_method    VARCHAR(50),
  payment_id        VARCHAR(255),
  subtotal          DECIMAL(10, 2) NOT NULL,
  tax               DECIMAL(10, 2) NOT NULL DEFAULT 0,
  service_charge    DECIMAL(10, 2) NOT NULL DEFAULT 0,
  discount          DECIMAL(10, 2) NOT NULL DEFAULT 0,
  total             DECIMAL(10, 2) NOT NULL,
  currency          VARCHAR(3) NOT NULL DEFAULT 'JOD',
  notes             TEXT,
  delivery_address  TEXT,
  estimated_ready   TIMESTAMPTZ,
  completed_at      TIMESTAMPTZ,
  canceled_at       TIMESTAMPTZ,
  cancel_reason     TEXT,
  created_at        TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at        TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX orders_restaurant_idx ON orders(restaurant_id);
CREATE INDEX orders_status_idx ON orders(restaurant_id, status);
CREATE INDEX orders_date_idx ON orders(restaurant_id, created_at);
CREATE INDEX orders_payment_idx ON orders(payment_id);

-- ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
-- ORDER ITEMS
-- ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

CREATE TABLE order_items (
  id                UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  order_id          UUID NOT NULL REFERENCES orders(id) ON DELETE CASCADE,
  dish_id           UUID REFERENCES dishes(id) ON DELETE SET NULL,
  dish_name         VARCHAR(255) NOT NULL,
  quantity          INTEGER NOT NULL DEFAULT 1,
  unit_price        DECIMAL(10, 2) NOT NULL,
  total_price       DECIMAL(10, 2) NOT NULL,
  selected_variants JSONB DEFAULT '{}',
  selected_addons   JSONB DEFAULT '[]',
  notes             TEXT
);

CREATE INDEX order_items_order_idx ON order_items(order_id);
CREATE INDEX order_items_dish_idx ON order_items(dish_id);

-- ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
-- SUBSCRIPTIONS
-- ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

CREATE TABLE subscriptions (
  id                      UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  restaurant_id           UUID NOT NULL REFERENCES restaurants(id) ON DELETE CASCADE,
  plan                    plan_tier NOT NULL DEFAULT 'base',
  status                  subscription_status NOT NULL DEFAULT 'trialing',
  stripe_customer_id      VARCHAR(255),
  stripe_subscription_id  VARCHAR(255),
  moyasar_subscription_id VARCHAR(255),
  current_period_start    TIMESTAMPTZ,
  current_period_end      TIMESTAMPTZ,
  trial_end               TIMESTAMPTZ,
  canceled_at             TIMESTAMPTZ,
  cancel_reason           TEXT,
  metadata                JSONB DEFAULT '{}',
  created_at              TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at              TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE UNIQUE INDEX subscriptions_restaurant_idx ON subscriptions(restaurant_id);
CREATE INDEX subscriptions_stripe_idx ON subscriptions(stripe_customer_id);
CREATE INDEX subscriptions_status_idx ON subscriptions(status);

-- ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
-- QR CODES
-- ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

CREATE TABLE qr_codes (
  id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  restaurant_id   UUID NOT NULL REFERENCES restaurants(id) ON DELETE CASCADE,
  menu_id         UUID REFERENCES menus(id) ON DELETE SET NULL,
  label           VARCHAR(255) NOT NULL,
  table_number    VARCHAR(20),
  url             VARCHAR(500) NOT NULL,
  svg_data        TEXT,
  scan_count      INTEGER NOT NULL DEFAULT 0,
  is_active       BOOLEAN NOT NULL DEFAULT true,
  created_at      TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX qr_codes_restaurant_idx ON qr_codes(restaurant_id);

-- ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
-- ANALYTICS EVENTS
-- ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

CREATE TABLE analytics_events (
  id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  restaurant_id   UUID NOT NULL REFERENCES restaurants(id) ON DELETE CASCADE,
  event           VARCHAR(100) NOT NULL,
  dish_id         UUID,
  category_id     UUID,
  order_id        UUID,
  session_id      VARCHAR(100),
  device_type     VARCHAR(20),
  language        VARCHAR(5),
  metadata        JSONB DEFAULT '{}',
  created_at      TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX analytics_restaurant_event_idx ON analytics_events(restaurant_id, event);
CREATE INDEX analytics_date_idx ON analytics_events(restaurant_id, created_at);
CREATE INDEX analytics_dish_idx ON analytics_events(dish_id);

-- ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
-- ASSETS
-- ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

CREATE TABLE assets (
  id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  restaurant_id   UUID NOT NULL REFERENCES restaurants(id) ON DELETE CASCADE,
  type            asset_type NOT NULL,
  url             VARCHAR(500) NOT NULL,
  key             VARCHAR(500) NOT NULL,
  filename        VARCHAR(255) NOT NULL,
  mime_type       VARCHAR(100) NOT NULL,
  size            INTEGER NOT NULL,
  width           INTEGER,
  height          INTEGER,
  alt             VARCHAR(255),
  created_at      TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX assets_restaurant_idx ON assets(restaurant_id);
CREATE INDEX assets_type_idx ON assets(restaurant_id, type);

-- ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
-- FEEDBACK
-- ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

CREATE TABLE feedback (
  id                UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  restaurant_id     UUID NOT NULL REFERENCES restaurants(id) ON DELETE CASCADE,
  order_id          UUID REFERENCES orders(id) ON DELETE SET NULL,
  customer_name     VARCHAR(255),
  customer_email    VARCHAR(255),
  rating            INTEGER NOT NULL CHECK (rating >= 1 AND rating <= 5),
  food_rating       INTEGER CHECK (food_rating >= 1 AND food_rating <= 5),
  service_rating    INTEGER CHECK (service_rating >= 1 AND service_rating <= 5),
  ambiance_rating   INTEGER CHECK (ambiance_rating >= 1 AND ambiance_rating <= 5),
  comment           TEXT,
  is_public         BOOLEAN NOT NULL DEFAULT false,
  created_at        TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX feedback_restaurant_idx ON feedback(restaurant_id);
CREATE INDEX feedback_rating_idx ON feedback(restaurant_id, rating);

-- ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
-- UPDATED_AT TRIGGER
-- ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

CREATE OR REPLACE FUNCTION update_updated_at()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER restaurants_updated_at BEFORE UPDATE ON restaurants FOR EACH ROW EXECUTE FUNCTION update_updated_at();
CREATE TRIGGER users_updated_at BEFORE UPDATE ON users FOR EACH ROW EXECUTE FUNCTION update_updated_at();
CREATE TRIGGER menus_updated_at BEFORE UPDATE ON menus FOR EACH ROW EXECUTE FUNCTION update_updated_at();
CREATE TRIGGER categories_updated_at BEFORE UPDATE ON categories FOR EACH ROW EXECUTE FUNCTION update_updated_at();
CREATE TRIGGER dishes_updated_at BEFORE UPDATE ON dishes FOR EACH ROW EXECUTE FUNCTION update_updated_at();
CREATE TRIGGER orders_updated_at BEFORE UPDATE ON orders FOR EACH ROW EXECUTE FUNCTION update_updated_at();
CREATE TRIGGER subscriptions_updated_at BEFORE UPDATE ON subscriptions FOR EACH ROW EXECUTE FUNCTION update_updated_at();

COMMIT;
