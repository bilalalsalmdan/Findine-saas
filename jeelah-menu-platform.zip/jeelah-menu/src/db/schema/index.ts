// src/db/schema/index.ts
// Complete Jeelah Menu Database Schema — Drizzle ORM + PostgreSQL
// Multi-tenant, ACID-safe, fully indexed

import {
  pgTable,
  uuid,
  varchar,
  text,
  boolean,
  integer,
  decimal,
  timestamp,
  jsonb,
  pgEnum,
  index,
  uniqueIndex,
  serial,
} from "drizzle-orm/pg-core";
import { relations } from "drizzle-orm";

// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
// ENUMS
// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

export const userRoleEnum = pgEnum("user_role", [
  "super_admin",
  "restaurant_owner",
  "restaurant_staff",
  "customer",
]);

export const subscriptionStatusEnum = pgEnum("subscription_status", [
  "trialing",
  "active",
  "past_due",
  "canceled",
  "unpaid",
]);

export const planTierEnum = pgEnum("plan_tier", [
  "base",
  "premium",
  "enterprise",
]);

export const orderStatusEnum = pgEnum("order_status", [
  "pending",
  "confirmed",
  "preparing",
  "ready",
  "delivered",
  "canceled",
]);

export const paymentStatusEnum = pgEnum("payment_status", [
  "pending",
  "paid",
  "failed",
  "refunded",
]);

export const menuTypeEnum = pgEnum("menu_type", [
  "dine_in",
  "takeaway",
  "delivery",
  "room_service",
]);

export const assetTypeEnum = pgEnum("asset_type", [
  "dish_image",
  "logo",
  "banner",
  "gallery",
  "menu_background",
]);

// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
// RESTAURANTS
// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

export const restaurants = pgTable(
  "restaurants",
  {
    id: uuid("id").defaultRandom().primaryKey(),
    name: varchar("name", { length: 255 }).notNull(),
    slug: varchar("slug", { length: 255 }).notNull(),
    description: text("description"),
    descriptionAr: text("description_ar"),
    logo: varchar("logo", { length: 500 }),
    banner: varchar("banner", { length: 500 }),
    phone: varchar("phone", { length: 20 }),
    email: varchar("email", { length: 255 }),
    website: varchar("website", { length: 500 }),
    address: text("address"),
    city: varchar("city", { length: 100 }),
    country: varchar("country", { length: 100 }).default("JO"),
    latitude: decimal("latitude", { precision: 10, scale: 7 }),
    longitude: decimal("longitude", { precision: 10, scale: 7 }),
    currency: varchar("currency", { length: 3 }).default("JOD").notNull(),
    timezone: varchar("timezone", { length: 50 }).default("Asia/Amman").notNull(),
    defaultLanguage: varchar("default_language", { length: 5 }).default("ar").notNull(),
    supportedLanguages: jsonb("supported_languages").default(["ar", "en"]).notNull(),
    theme: jsonb("theme").default({
      primaryColor: "#E6034B",
      fontFamily: "DM Sans",
      borderRadius: "1.25rem",
      darkMode: false,
    }),
    settings: jsonb("settings").default({
      showPrices: true,
      showCalories: true,
      showAllergens: true,
      allowOrdering: true,
      allowFeedback: true,
      showRecommendations: true,
      taxRate: 0.16,
      serviceCharge: 0,
    }),
    socialLinks: jsonb("social_links").default({}),
    isActive: boolean("is_active").default(true).notNull(),
    createdAt: timestamp("created_at").defaultNow().notNull(),
    updatedAt: timestamp("updated_at").defaultNow().notNull(),
  },
  (table) => ({
    slugIdx: uniqueIndex("restaurants_slug_idx").on(table.slug),
    cityIdx: index("restaurants_city_idx").on(table.city),
    activeIdx: index("restaurants_active_idx").on(table.isActive),
  })
);

// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
// USERS
// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

export const users = pgTable(
  "users",
  {
    id: uuid("id").defaultRandom().primaryKey(),
    email: varchar("email", { length: 255 }).notNull(),
    passwordHash: varchar("password_hash", { length: 255 }).notNull(),
    name: varchar("name", { length: 255 }).notNull(),
    nameAr: varchar("name_ar", { length: 255 }),
    phone: varchar("phone", { length: 20 }),
    avatar: varchar("avatar", { length: 500 }),
    role: userRoleEnum("role").default("restaurant_owner").notNull(),
    restaurantId: uuid("restaurant_id").references(() => restaurants.id, {
      onDelete: "cascade",
    }),
    emailVerified: boolean("email_verified").default(false).notNull(),
    lastLoginAt: timestamp("last_login_at"),
    isActive: boolean("is_active").default(true).notNull(),
    createdAt: timestamp("created_at").defaultNow().notNull(),
    updatedAt: timestamp("updated_at").defaultNow().notNull(),
  },
  (table) => ({
    emailIdx: uniqueIndex("users_email_idx").on(table.email),
    restaurantIdx: index("users_restaurant_idx").on(table.restaurantId),
    roleIdx: index("users_role_idx").on(table.role),
  })
);

// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
// REFRESH TOKENS
// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

export const refreshTokens = pgTable(
  "refresh_tokens",
  {
    id: uuid("id").defaultRandom().primaryKey(),
    userId: uuid("user_id")
      .references(() => users.id, { onDelete: "cascade" })
      .notNull(),
    token: varchar("token", { length: 500 }).notNull(),
    expiresAt: timestamp("expires_at").notNull(),
    createdAt: timestamp("created_at").defaultNow().notNull(),
  },
  (table) => ({
    tokenIdx: uniqueIndex("refresh_tokens_token_idx").on(table.token),
    userIdx: index("refresh_tokens_user_idx").on(table.userId),
    expiresIdx: index("refresh_tokens_expires_idx").on(table.expiresAt),
  })
);

// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
// MENUS
// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

export const menus = pgTable(
  "menus",
  {
    id: uuid("id").defaultRandom().primaryKey(),
    restaurantId: uuid("restaurant_id")
      .references(() => restaurants.id, { onDelete: "cascade" })
      .notNull(),
    name: varchar("name", { length: 255 }).notNull(),
    nameAr: varchar("name_ar", { length: 255 }),
    description: text("description"),
    descriptionAr: text("description_ar"),
    type: menuTypeEnum("type").default("dine_in").notNull(),
    isActive: boolean("is_active").default(true).notNull(),
    isDefault: boolean("is_default").default(false).notNull(),
    sortOrder: integer("sort_order").default(0).notNull(),
    availableFrom: varchar("available_from", { length: 5 }), // HH:MM
    availableTo: varchar("available_to", { length: 5 }),
    availableDays: jsonb("available_days").default([0, 1, 2, 3, 4, 5, 6]),
    createdAt: timestamp("created_at").defaultNow().notNull(),
    updatedAt: timestamp("updated_at").defaultNow().notNull(),
  },
  (table) => ({
    restaurantIdx: index("menus_restaurant_idx").on(table.restaurantId),
    activeIdx: index("menus_active_idx").on(table.isActive),
    sortIdx: index("menus_sort_idx").on(table.restaurantId, table.sortOrder),
  })
);

// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
// CATEGORIES
// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

export const categories = pgTable(
  "categories",
  {
    id: uuid("id").defaultRandom().primaryKey(),
    restaurantId: uuid("restaurant_id")
      .references(() => restaurants.id, { onDelete: "cascade" })
      .notNull(),
    menuId: uuid("menu_id")
      .references(() => menus.id, { onDelete: "cascade" })
      .notNull(),
    name: varchar("name", { length: 255 }).notNull(),
    nameAr: varchar("name_ar", { length: 255 }),
    description: text("description"),
    descriptionAr: text("description_ar"),
    image: varchar("image", { length: 500 }),
    icon: varchar("icon", { length: 50 }),
    sortOrder: integer("sort_order").default(0).notNull(),
    isActive: boolean("is_active").default(true).notNull(),
    createdAt: timestamp("created_at").defaultNow().notNull(),
    updatedAt: timestamp("updated_at").defaultNow().notNull(),
  },
  (table) => ({
    restaurantIdx: index("categories_restaurant_idx").on(table.restaurantId),
    menuIdx: index("categories_menu_idx").on(table.menuId),
    sortIdx: index("categories_sort_idx").on(table.menuId, table.sortOrder),
  })
);

// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
// DISHES
// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

export const dishes = pgTable(
  "dishes",
  {
    id: uuid("id").defaultRandom().primaryKey(),
    restaurantId: uuid("restaurant_id")
      .references(() => restaurants.id, { onDelete: "cascade" })
      .notNull(),
    categoryId: uuid("category_id")
      .references(() => categories.id, { onDelete: "cascade" })
      .notNull(),
    name: varchar("name", { length: 255 }).notNull(),
    nameAr: varchar("name_ar", { length: 255 }),
    description: text("description"),
    descriptionAr: text("description_ar"),
    price: decimal("price", { precision: 10, scale: 2 }).notNull(),
    compareAtPrice: decimal("compare_at_price", { precision: 10, scale: 2 }),
    image: varchar("image", { length: 500 }),
    images: jsonb("images").default([]),
    calories: integer("calories"),
    prepTime: integer("prep_time"), // minutes
    spiceLevel: integer("spice_level"), // 0-5
    allergens: jsonb("allergens").default([]),
    // e.g. ["gluten", "dairy", "nuts", "shellfish", "soy", "eggs"]
    dietaryTags: jsonb("dietary_tags").default([]),
    // e.g. ["vegan", "vegetarian", "halal", "gluten-free", "keto"]
    nutritionInfo: jsonb("nutrition_info").default({}),
    // { protein: 25, carbs: 30, fat: 12, fiber: 3 }
    ingredients: jsonb("ingredients").default([]),
    variants: jsonb("variants").default([]),
    // [{ name: "Size", options: [{ name: "Small", price: 3.5 }, { name: "Large", price: 5.5 }] }]
    addons: jsonb("addons").default([]),
    // [{ name: "Extra cheese", price: 1.0 }]
    isAvailable: boolean("is_available").default(true).notNull(),
    isFeatured: boolean("is_featured").default(false).notNull(),
    isNew: boolean("is_new").default(false).notNull(),
    sortOrder: integer("sort_order").default(0).notNull(),
    aiGenerated: boolean("ai_generated").default(false),
    createdAt: timestamp("created_at").defaultNow().notNull(),
    updatedAt: timestamp("updated_at").defaultNow().notNull(),
  },
  (table) => ({
    restaurantIdx: index("dishes_restaurant_idx").on(table.restaurantId),
    categoryIdx: index("dishes_category_idx").on(table.categoryId),
    availableIdx: index("dishes_available_idx").on(
      table.restaurantId,
      table.isAvailable
    ),
    featuredIdx: index("dishes_featured_idx").on(
      table.restaurantId,
      table.isFeatured
    ),
    sortIdx: index("dishes_sort_idx").on(table.categoryId, table.sortOrder),
    priceIdx: index("dishes_price_idx").on(table.restaurantId, table.price),
  })
);

// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
// ORDERS
// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

export const orders = pgTable(
  "orders",
  {
    id: uuid("id").defaultRandom().primaryKey(),
    orderNumber: serial("order_number"),
    restaurantId: uuid("restaurant_id")
      .references(() => restaurants.id, { onDelete: "cascade" })
      .notNull(),
    customerName: varchar("customer_name", { length: 255 }),
    customerPhone: varchar("customer_phone", { length: 20 }),
    customerEmail: varchar("customer_email", { length: 255 }),
    tableNumber: varchar("table_number", { length: 20 }),
    roomNumber: varchar("room_number", { length: 20 }),
    type: menuTypeEnum("type").default("dine_in").notNull(),
    status: orderStatusEnum("status").default("pending").notNull(),
    paymentStatus: paymentStatusEnum("payment_status")
      .default("pending")
      .notNull(),
    paymentMethod: varchar("payment_method", { length: 50 }),
    paymentId: varchar("payment_id", { length: 255 }),
    subtotal: decimal("subtotal", { precision: 10, scale: 2 }).notNull(),
    tax: decimal("tax", { precision: 10, scale: 2 }).default("0").notNull(),
    serviceCharge: decimal("service_charge", { precision: 10, scale: 2 })
      .default("0")
      .notNull(),
    discount: decimal("discount", { precision: 10, scale: 2 })
      .default("0")
      .notNull(),
    total: decimal("total", { precision: 10, scale: 2 }).notNull(),
    currency: varchar("currency", { length: 3 }).default("JOD").notNull(),
    notes: text("notes"),
    deliveryAddress: text("delivery_address"),
    estimatedReady: timestamp("estimated_ready"),
    completedAt: timestamp("completed_at"),
    canceledAt: timestamp("canceled_at"),
    cancelReason: text("cancel_reason"),
    createdAt: timestamp("created_at").defaultNow().notNull(),
    updatedAt: timestamp("updated_at").defaultNow().notNull(),
  },
  (table) => ({
    restaurantIdx: index("orders_restaurant_idx").on(table.restaurantId),
    statusIdx: index("orders_status_idx").on(
      table.restaurantId,
      table.status
    ),
    dateIdx: index("orders_date_idx").on(
      table.restaurantId,
      table.createdAt
    ),
    paymentIdx: index("orders_payment_idx").on(table.paymentId),
  })
);

// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
// ORDER ITEMS
// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

export const orderItems = pgTable(
  "order_items",
  {
    id: uuid("id").defaultRandom().primaryKey(),
    orderId: uuid("order_id")
      .references(() => orders.id, { onDelete: "cascade" })
      .notNull(),
    dishId: uuid("dish_id")
      .references(() => dishes.id, { onDelete: "set null" }),
    dishName: varchar("dish_name", { length: 255 }).notNull(), // denormalized
    quantity: integer("quantity").default(1).notNull(),
    unitPrice: decimal("unit_price", { precision: 10, scale: 2 }).notNull(),
    totalPrice: decimal("total_price", { precision: 10, scale: 2 }).notNull(),
    selectedVariants: jsonb("selected_variants").default({}),
    selectedAddons: jsonb("selected_addons").default([]),
    notes: text("notes"),
  },
  (table) => ({
    orderIdx: index("order_items_order_idx").on(table.orderId),
    dishIdx: index("order_items_dish_idx").on(table.dishId),
  })
);

// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
// SUBSCRIPTIONS
// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

export const subscriptions = pgTable(
  "subscriptions",
  {
    id: uuid("id").defaultRandom().primaryKey(),
    restaurantId: uuid("restaurant_id")
      .references(() => restaurants.id, { onDelete: "cascade" })
      .notNull(),
    plan: planTierEnum("plan").default("base").notNull(),
    status: subscriptionStatusEnum("status").default("trialing").notNull(),
    stripeCustomerId: varchar("stripe_customer_id", { length: 255 }),
    stripeSubscriptionId: varchar("stripe_subscription_id", { length: 255 }),
    moyasarSubscriptionId: varchar("moyasar_subscription_id", { length: 255 }),
    currentPeriodStart: timestamp("current_period_start"),
    currentPeriodEnd: timestamp("current_period_end"),
    trialEnd: timestamp("trial_end"),
    canceledAt: timestamp("canceled_at"),
    cancelReason: text("cancel_reason"),
    metadata: jsonb("metadata").default({}),
    createdAt: timestamp("created_at").defaultNow().notNull(),
    updatedAt: timestamp("updated_at").defaultNow().notNull(),
  },
  (table) => ({
    restaurantIdx: uniqueIndex("subscriptions_restaurant_idx").on(
      table.restaurantId
    ),
    stripeIdx: index("subscriptions_stripe_idx").on(table.stripeCustomerId),
    statusIdx: index("subscriptions_status_idx").on(table.status),
  })
);

// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
// QR CODES
// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

export const qrCodes = pgTable(
  "qr_codes",
  {
    id: uuid("id").defaultRandom().primaryKey(),
    restaurantId: uuid("restaurant_id")
      .references(() => restaurants.id, { onDelete: "cascade" })
      .notNull(),
    menuId: uuid("menu_id").references(() => menus.id, {
      onDelete: "set null",
    }),
    label: varchar("label", { length: 255 }).notNull(),
    tableNumber: varchar("table_number", { length: 20 }),
    url: varchar("url", { length: 500 }).notNull(),
    svgData: text("svg_data"),
    scanCount: integer("scan_count").default(0).notNull(),
    isActive: boolean("is_active").default(true).notNull(),
    createdAt: timestamp("created_at").defaultNow().notNull(),
  },
  (table) => ({
    restaurantIdx: index("qr_codes_restaurant_idx").on(table.restaurantId),
  })
);

// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
// ANALYTICS EVENTS
// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

export const analyticsEvents = pgTable(
  "analytics_events",
  {
    id: uuid("id").defaultRandom().primaryKey(),
    restaurantId: uuid("restaurant_id")
      .references(() => restaurants.id, { onDelete: "cascade" })
      .notNull(),
    event: varchar("event", { length: 100 }).notNull(),
    // "menu_view", "dish_view", "add_to_cart", "order_placed", "qr_scan", "feedback"
    dishId: uuid("dish_id"),
    categoryId: uuid("category_id"),
    orderId: uuid("order_id"),
    sessionId: varchar("session_id", { length: 100 }),
    deviceType: varchar("device_type", { length: 20 }),
    language: varchar("language", { length: 5 }),
    metadata: jsonb("metadata").default({}),
    createdAt: timestamp("created_at").defaultNow().notNull(),
  },
  (table) => ({
    restaurantEventIdx: index("analytics_restaurant_event_idx").on(
      table.restaurantId,
      table.event
    ),
    dateIdx: index("analytics_date_idx").on(
      table.restaurantId,
      table.createdAt
    ),
    dishIdx: index("analytics_dish_idx").on(table.dishId),
  })
);

// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
// ASSETS
// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

export const assets = pgTable(
  "assets",
  {
    id: uuid("id").defaultRandom().primaryKey(),
    restaurantId: uuid("restaurant_id")
      .references(() => restaurants.id, { onDelete: "cascade" })
      .notNull(),
    type: assetTypeEnum("type").notNull(),
    url: varchar("url", { length: 500 }).notNull(),
    key: varchar("key", { length: 500 }).notNull(), // R2 object key
    filename: varchar("filename", { length: 255 }).notNull(),
    mimeType: varchar("mime_type", { length: 100 }).notNull(),
    size: integer("size").notNull(), // bytes
    width: integer("width"),
    height: integer("height"),
    alt: varchar("alt", { length: 255 }),
    createdAt: timestamp("created_at").defaultNow().notNull(),
  },
  (table) => ({
    restaurantIdx: index("assets_restaurant_idx").on(table.restaurantId),
    typeIdx: index("assets_type_idx").on(table.restaurantId, table.type),
  })
);

// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
// FEEDBACK
// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

export const feedback = pgTable(
  "feedback",
  {
    id: uuid("id").defaultRandom().primaryKey(),
    restaurantId: uuid("restaurant_id")
      .references(() => restaurants.id, { onDelete: "cascade" })
      .notNull(),
    orderId: uuid("order_id").references(() => orders.id, {
      onDelete: "set null",
    }),
    customerName: varchar("customer_name", { length: 255 }),
    customerEmail: varchar("customer_email", { length: 255 }),
    rating: integer("rating").notNull(), // 1-5
    foodRating: integer("food_rating"),
    serviceRating: integer("service_rating"),
    ambianceRating: integer("ambiance_rating"),
    comment: text("comment"),
    isPublic: boolean("is_public").default(false).notNull(),
    createdAt: timestamp("created_at").defaultNow().notNull(),
  },
  (table) => ({
    restaurantIdx: index("feedback_restaurant_idx").on(table.restaurantId),
    ratingIdx: index("feedback_rating_idx").on(
      table.restaurantId,
      table.rating
    ),
  })
);

// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
// RELATIONS
// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

export const restaurantRelations = relations(restaurants, ({ many, one }) => ({
  users: many(users),
  menus: many(menus),
  categories: many(categories),
  dishes: many(dishes),
  orders: many(orders),
  subscription: one(subscriptions),
  qrCodes: many(qrCodes),
  analytics: many(analyticsEvents),
  assets: many(assets),
  feedback: many(feedback),
}));

export const userRelations = relations(users, ({ one }) => ({
  restaurant: one(restaurants, {
    fields: [users.restaurantId],
    references: [restaurants.id],
  }),
}));

export const menuRelations = relations(menus, ({ one, many }) => ({
  restaurant: one(restaurants, {
    fields: [menus.restaurantId],
    references: [restaurants.id],
  }),
  categories: many(categories),
}));

export const categoryRelations = relations(categories, ({ one, many }) => ({
  restaurant: one(restaurants, {
    fields: [categories.restaurantId],
    references: [restaurants.id],
  }),
  menu: one(menus, {
    fields: [categories.menuId],
    references: [menus.id],
  }),
  dishes: many(dishes),
}));

export const dishRelations = relations(dishes, ({ one }) => ({
  restaurant: one(restaurants, {
    fields: [dishes.restaurantId],
    references: [restaurants.id],
  }),
  category: one(categories, {
    fields: [dishes.categoryId],
    references: [categories.id],
  }),
}));

export const orderRelations = relations(orders, ({ one, many }) => ({
  restaurant: one(restaurants, {
    fields: [orders.restaurantId],
    references: [restaurants.id],
  }),
  items: many(orderItems),
}));

export const orderItemRelations = relations(orderItems, ({ one }) => ({
  order: one(orders, {
    fields: [orderItems.orderId],
    references: [orders.id],
  }),
  dish: one(dishes, {
    fields: [orderItems.dishId],
    references: [dishes.id],
  }),
}));

export const subscriptionRelations = relations(subscriptions, ({ one }) => ({
  restaurant: one(restaurants, {
    fields: [subscriptions.restaurantId],
    references: [restaurants.id],
  }),
}));
