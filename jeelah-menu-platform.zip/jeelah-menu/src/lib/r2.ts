import {
  S3Client,
  PutObjectCommand,
  DeleteObjectCommand,
  GetObjectCommand,
} from "@aws-sdk/client-s3";
import { getSignedUrl } from "@aws-sdk/s3-request-presigner";
import sharp from "sharp";

const R2 = new S3Client({
  region: "auto",
  endpoint: process.env.R2_ENDPOINT!,
  credentials: {
    accessKeyId: process.env.R2_ACCESS_KEY_ID!,
    secretAccessKey: process.env.R2_SECRET_ACCESS_KEY!,
  },
});

const BUCKET = process.env.R2_BUCKET_NAME!;
const PUBLIC_URL = process.env.R2_PUBLIC_URL!;

// ━━━ Image Processing + Upload ━━━

interface UploadOptions {
  restaurantId: string;
  type: "dish" | "logo" | "banner" | "gallery";
  filename: string;
  buffer: Buffer;
  mimeType: string;
}

interface UploadResult {
  url: string;
  key: string;
  width: number;
  height: number;
  size: number;
}

export async function uploadImage(
  options: UploadOptions
): Promise<UploadResult> {
  const { restaurantId, type, filename, buffer, mimeType } = options;

  // Process image with sharp
  const processed = sharp(buffer);
  const metadata = await processed.metadata();

  // Resize based on type
  const maxWidths: Record<string, number> = {
    dish: 1200,
    logo: 400,
    banner: 1920,
    gallery: 1600,
  };

  const maxWidth = maxWidths[type] || 1200;
  const resized = await processed
    .resize({ width: maxWidth, withoutEnlargement: true })
    .webp({ quality: 85 })
    .toBuffer();

  const resizedMeta = await sharp(resized).metadata();

  // Generate key
  const timestamp = Date.now();
  const ext = "webp";
  const key = `restaurants/${restaurantId}/${type}/${timestamp}-${filename.replace(
    /\.[^/.]+$/,
    ""
  )}.${ext}`;

  // Upload to R2
  await R2.send(
    new PutObjectCommand({
      Bucket: BUCKET,
      Key: key,
      Body: resized,
      ContentType: "image/webp",
      CacheControl: "public, max-age=31536000, immutable",
    })
  );

  return {
    url: `${PUBLIC_URL}/${key}`,
    key,
    width: resizedMeta.width || 0,
    height: resizedMeta.height || 0,
    size: resized.length,
  };
}

// ━━━ Delete Image ━━━

export async function deleteImage(key: string): Promise<void> {
  await R2.send(
    new DeleteObjectCommand({
      Bucket: BUCKET,
      Key: key,
    })
  );
}

// ━━━ Generate Presigned Upload URL ━━━

export async function getPresignedUploadUrl(
  key: string,
  contentType: string
): Promise<string> {
  const command = new PutObjectCommand({
    Bucket: BUCKET,
    Key: key,
    ContentType: contentType,
  });

  return getSignedUrl(R2, command, { expiresIn: 3600 });
}
