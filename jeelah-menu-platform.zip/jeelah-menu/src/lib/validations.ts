import { z } from "zod";

// ━━━ Auth ━━━

export const loginSchema = z.object({
  email: z.string().email("Invalid email address"),
  password: z.string().min(8, "Password must be at least 8 characters"),
});

export const registerSchema = z.object({
  name: z.string().min(2).max(255),
  email: z.string().email(),
  password: z
    .string()
    .min(8)
    .regex(
      /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)/,
      "Password must contain uppercase, lowercase, and number"
    ),
  restaurantName: z.string().min(2).max(255),
  phone: z.string().optional(),
  country: z.string().default("JO"),
});

// ━━━ Restaurant ━━━

export const updateRestaurantSchema = z.object({
  name: z.string().min(2).max(255).optional(),
  description: z.string().max(2000).optional(),
  descriptionAr: z.string().max(2000).optional(),
  phone: z.string().optional(),
  email: z.string().email().optional(),
  website: z.string().url().optional(),
  address: z.string().optional(),
  city: z.string().optional(),
  currency: z.string().length(3).optional(),
  defaultLanguage: z.enum(["ar", "en", "tr", "fr"]).optional(),
  theme: z
    .object({
      primaryColor: z.string().optional(),
      fontFamily: z.string().optional(),
      borderRadius: z.string().optional(),
      darkMode: z.boolean().optional(),
    })
    .optional(),
  settings: z
    .object({
      showPrices: z.boolean().optional(),
      showCalories: z.boolean().optional(),
      showAllergens: z.boolean().optional(),
      allowOrdering: z.boolean().optional(),
      allowFeedback: z.boolean().optional(),
      taxRate: z.number().min(0).max(1).optional(),
      serviceCharge: z.number().min(0).max(1).optional(),
    })
    .optional(),
});

// ━━━ Menu ━━━

export const createMenuSchema = z.object({
  name: z.string().min(1).max(255),
  nameAr: z.string().max(255).optional(),
  description: z.string().max(1000).optional(),
  type: z.enum(["dine_in", "takeaway", "delivery", "room_service"]).default("dine_in"),
  availableFrom: z.string().regex(/^\d{2}:\d{2}$/).optional(),
  availableTo: z.string().regex(/^\d{2}:\d{2}$/).optional(),
  availableDays: z.array(z.number().min(0).max(6)).optional(),
});

// ━━━ Category ━━━

export const createCategorySchema = z.object({
  menuId: z.string().uuid(),
  name: z.string().min(1).max(255),
  nameAr: z.string().max(255).optional(),
  description: z.string().max(500).optional(),
  icon: z.string().max(50).optional(),
  sortOrder: z.number().int().optional(),
});

// ━━━ Dish ━━━

export const createDishSchema = z.object({
  categoryId: z.string().uuid(),
  name: z.string().min(1).max(255),
  nameAr: z.string().max(255).optional(),
  description: z.string().max(2000).optional(),
  descriptionAr: z.string().max(2000).optional(),
  price: z.number().positive(),
  compareAtPrice: z.number().positive().optional(),
  image: z.string().url().optional(),
  calories: z.number().int().positive().optional(),
  prepTime: z.number().int().positive().optional(),
  spiceLevel: z.number().int().min(0).max(5).optional(),
  allergens: z.array(z.string()).optional(),
  dietaryTags: z.array(z.string()).optional(),
  ingredients: z.array(z.string()).optional(),
  variants: z
    .array(
      z.object({
        name: z.string(),
        options: z.array(z.object({ name: z.string(), price: z.number() })),
      })
    )
    .optional(),
  addons: z
    .array(z.object({ name: z.string(), price: z.number() }))
    .optional(),
  isFeatured: z.boolean().optional(),
  isNew: z.boolean().optional(),
  sortOrder: z.number().int().optional(),
});

// ━━━ Order ━━━

export const createOrderSchema = z.object({
  customerName: z.string().optional(),
  customerPhone: z.string().optional(),
  customerEmail: z.string().email().optional(),
  tableNumber: z.string().optional(),
  roomNumber: z.string().optional(),
  type: z.enum(["dine_in", "takeaway", "delivery", "room_service"]).default("dine_in"),
  items: z
    .array(
      z.object({
        dishId: z.string().uuid(),
        quantity: z.number().int().min(1),
        selectedVariants: z.record(z.string()).optional(),
        selectedAddons: z.array(z.string()).optional(),
        notes: z.string().optional(),
      })
    )
    .min(1),
  notes: z.string().optional(),
  deliveryAddress: z.string().optional(),
  paymentMethod: z.string().optional(),
});

// ━━━ Feedback ━━━

export const createFeedbackSchema = z.object({
  orderId: z.string().uuid().optional(),
  customerName: z.string().optional(),
  customerEmail: z.string().email().optional(),
  rating: z.number().int().min(1).max(5),
  foodRating: z.number().int().min(1).max(5).optional(),
  serviceRating: z.number().int().min(1).max(5).optional(),
  ambianceRating: z.number().int().min(1).max(5).optional(),
  comment: z.string().max(2000).optional(),
});

// ━━━ Types ━━━

export type LoginInput = z.infer<typeof loginSchema>;
export type RegisterInput = z.infer<typeof registerSchema>;
export type UpdateRestaurantInput = z.infer<typeof updateRestaurantSchema>;
export type CreateMenuInput = z.infer<typeof createMenuSchema>;
export type CreateCategoryInput = z.infer<typeof createCategorySchema>;
export type CreateDishInput = z.infer<typeof createDishSchema>;
export type CreateOrderInput = z.infer<typeof createOrderSchema>;
export type CreateFeedbackInput = z.infer<typeof createFeedbackSchema>;
