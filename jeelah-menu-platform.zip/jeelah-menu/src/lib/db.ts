import { neon } from "@neondatabase/serverless";
import { drizzle } from "drizzle-orm/neon-http";
import * as schema from "@/db/schema";

const sql = neon(process.env.DATABASE_URL!);

export const db = drizzle(sql, { schema });

// Tenant-scoped query helper
export type TenantContext = {
  restaurantId: string;
  userId?: string;
  role?: string;
};

export async function withTenant<T>(
  restaurantId: string,
  fn: (ctx: TenantContext) => Promise<T>
): Promise<T> {
  if (!restaurantId) {
    throw new Error("Restaurant ID is required for tenant-scoped queries");
  }
  return fn({ restaurantId });
}
