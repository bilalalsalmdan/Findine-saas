import Anthropic from "@anthropic-ai/sdk";

const anthropic = new Anthropic({
  apiKey: process.env.ANTHROPIC_API_KEY!,
});

// ━━━ AI Dish Description Generator ━━━

interface DishDescriptionInput {
  name: string;
  category: string;
  ingredients?: string[];
  cuisine?: string;
  language?: "en" | "ar";
}

export async function generateDishDescription(
  input: DishDescriptionInput
): Promise<string> {
  const { name, category, ingredients, cuisine, language = "en" } = input;

  const prompt =
    language === "ar"
      ? `اكتب وصفاً شهياً ومختصراً (جملة أو جملتين) لطبق "${name}" من فئة "${category}"${
          ingredients ? ` يحتوي على: ${ingredients.join("، ")}` : ""
        }${cuisine ? ` من المطبخ ${cuisine}` : ""}. اجعل الوصف جذاباً ويُثير الشهية.`
      : `Write an appetizing, concise description (1-2 sentences) for a dish called "${name}" in the "${category}" category${
          ingredients ? ` made with: ${ingredients.join(", ")}` : ""
        }${
          cuisine ? ` from ${cuisine} cuisine` : ""
        }. Make it enticing and mouth-watering.`;

  const message = await anthropic.messages.create({
    model: "claude-sonnet-4-20250514",
    max_tokens: 200,
    messages: [{ role: "user", content: prompt }],
  });

  const textBlock = message.content.find((block) => block.type === "text");
  return textBlock?.text ?? "";
}

// ━━━ AI Translation ━━━

interface TranslationInput {
  text: string;
  from: "en" | "ar";
  to: "en" | "ar";
  context?: string; // "menu_item", "description", "category"
}

export async function translateText(
  input: TranslationInput
): Promise<string> {
  const { text, from, to, context = "menu_item" } = input;

  const prompt = `Translate the following ${context} from ${
    from === "en" ? "English" : "Arabic"
  } to ${
    to === "en" ? "English" : "Arabic"
  }. Keep it natural and appropriate for a restaurant menu. Return ONLY the translation, nothing else.

Text: "${text}"`;

  const message = await anthropic.messages.create({
    model: "claude-sonnet-4-20250514",
    max_tokens: 500,
    messages: [{ role: "user", content: prompt }],
  });

  const textBlock = message.content.find((block) => block.type === "text");
  return textBlock?.text ?? "";
}

// ━━━ AI Social Media Copy ━━━

interface SocialCopyInput {
  dishName: string;
  description: string;
  platform: "instagram" | "twitter" | "facebook";
  tone?: "casual" | "elegant" | "playful";
  language?: "en" | "ar";
}

export async function generateSocialCopy(
  input: SocialCopyInput
): Promise<string> {
  const {
    dishName,
    description,
    platform,
    tone = "casual",
    language = "en",
  } = input;

  const charLimit =
    platform === "twitter" ? 280 : platform === "instagram" ? 2200 : 500;

  const prompt =
    language === "ar"
      ? `اكتب منشوراً لـ ${platform} عن طبق "${dishName}": ${description}. النبرة: ${tone}. الحد الأقصى: ${charLimit} حرف. أضف هاشتاقات مناسبة.`
      : `Write a ${platform} post about "${dishName}": ${description}. Tone: ${tone}. Max ${charLimit} chars. Include relevant hashtags.`;

  const message = await anthropic.messages.create({
    model: "claude-sonnet-4-20250514",
    max_tokens: 500,
    messages: [{ role: "user", content: prompt }],
  });

  const textBlock = message.content.find((block) => block.type === "text");
  return textBlock?.text ?? "";
}
