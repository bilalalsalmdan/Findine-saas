import { NextRequest, NextResponse } from "next/server";
import { z } from "zod";
import { db } from "@/lib/db";
import { dishes } from "@/db/schema";
import { eq, and, desc, asc } from "drizzle-orm";
import { requireSession } from "@/lib/auth";

// ━━━ GET /api/dishes — List dishes for restaurant ━━━

export async function GET(request: NextRequest) {
  try {
    const session = await requireSession();
    const { searchParams } = new URL(request.url);

    const categoryId = searchParams.get("categoryId");
    const featured = searchParams.get("featured");
    const available = searchParams.get("available");
    const sort = searchParams.get("sort") || "sortOrder";

    const conditions = [eq(dishes.restaurantId, session.restaurantId!)];

    if (categoryId) conditions.push(eq(dishes.categoryId, categoryId));
    if (featured === "true") conditions.push(eq(dishes.isFeatured, true));
    if (available !== "false")
      conditions.push(eq(dishes.isAvailable, true));

    const orderBy =
      sort === "price"
        ? asc(dishes.price)
        : sort === "name"
        ? asc(dishes.name)
        : sort === "newest"
        ? desc(dishes.createdAt)
        : asc(dishes.sortOrder);

    const results = await db
      .select()
      .from(dishes)
      .where(and(...conditions))
      .orderBy(orderBy);

    return NextResponse.json({ dishes: results });
  } catch (error: any) {
    if (error.message === "Unauthorized") {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
    }
    console.error("Dishes GET error:", error);
    return NextResponse.json(
      { error: "Internal server error" },
      { status: 500 }
    );
  }
}

// ━━━ POST /api/dishes — Create dish ━━━

const createDishSchema = z.object({
  categoryId: z.string().uuid(),
  name: z.string().min(1).max(255),
  nameAr: z.string().optional(),
  description: z.string().optional(),
  descriptionAr: z.string().optional(),
  price: z.number().positive(),
  compareAtPrice: z.number().positive().optional(),
  image: z.string().url().optional(),
  calories: z.number().int().positive().optional(),
  prepTime: z.number().int().positive().optional(),
  spiceLevel: z.number().int().min(0).max(5).optional(),
  allergens: z.array(z.string()).optional(),
  dietaryTags: z.array(z.string()).optional(),
  ingredients: z.array(z.string()).optional(),
  variants: z
    .array(
      z.object({
        name: z.string(),
        options: z.array(
          z.object({ name: z.string(), price: z.number() })
        ),
      })
    )
    .optional(),
  addons: z
    .array(z.object({ name: z.string(), price: z.number() }))
    .optional(),
  isFeatured: z.boolean().optional(),
  isNew: z.boolean().optional(),
  sortOrder: z.number().int().optional(),
});

export async function POST(request: NextRequest) {
  try {
    const session = await requireSession();
    const body = await request.json();
    const data = createDishSchema.parse(body);

    const [dish] = await db
      .insert(dishes)
      .values({
        restaurantId: session.restaurantId!,
        categoryId: data.categoryId,
        name: data.name,
        nameAr: data.nameAr,
        description: data.description,
        descriptionAr: data.descriptionAr,
        price: data.price.toString(),
        compareAtPrice: data.compareAtPrice?.toString(),
        image: data.image,
        calories: data.calories,
        prepTime: data.prepTime,
        spiceLevel: data.spiceLevel,
        allergens: data.allergens || [],
        dietaryTags: data.dietaryTags || [],
        ingredients: data.ingredients || [],
        variants: data.variants || [],
        addons: data.addons || [],
        isFeatured: data.isFeatured || false,
        isNew: data.isNew || false,
        sortOrder: data.sortOrder || 0,
      })
      .returning();

    return NextResponse.json({ dish }, { status: 201 });
  } catch (error: any) {
    if (error instanceof z.ZodError) {
      return NextResponse.json(
        { error: "Validation failed", details: error.errors },
        { status: 400 }
      );
    }
    if (error.message === "Unauthorized") {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
    }
    console.error("Dishes POST error:", error);
    return NextResponse.json(
      { error: "Internal server error" },
      { status: 500 }
    );
  }
}
