import { NextRequest, NextResponse } from "next/server";
import { requireSession } from "@/lib/auth";
import { uploadImage } from "@/lib/r2";
import { db } from "@/lib/db";
import { assets } from "@/db/schema";

export async function POST(request: NextRequest) {
  try {
    const session = await requireSession();

    const formData = await request.formData();
    const file = formData.get("file") as File;
    const type = (formData.get("type") as string) || "dish_image";

    if (!file) {
      return NextResponse.json({ error: "No file provided" }, { status: 400 });
    }

    // Validate file
    const MAX_SIZE = 10 * 1024 * 1024; // 10MB
    if (file.size > MAX_SIZE) {
      return NextResponse.json(
        { error: "File too large. Max 10MB." },
        { status: 400 }
      );
    }

    const allowedTypes = ["image/jpeg", "image/png", "image/webp", "image/gif"];
    if (!allowedTypes.includes(file.type)) {
      return NextResponse.json(
        { error: "Invalid file type. Use JPEG, PNG, WebP, or GIF." },
        { status: 400 }
      );
    }

    const buffer = Buffer.from(await file.arrayBuffer());

    const result = await uploadImage({
      restaurantId: session.restaurantId!,
      type: type as "dish" | "logo" | "banner" | "gallery",
      filename: file.name,
      buffer,
      mimeType: file.type,
    });

    // Save to assets table
    const [asset] = await db
      .insert(assets)
      .values({
        restaurantId: session.restaurantId!,
        type: type as any,
        url: result.url,
        key: result.key,
        filename: file.name,
        mimeType: "image/webp",
        size: result.size,
        width: result.width,
        height: result.height,
      })
      .returning();

    return NextResponse.json({
      asset: {
        id: asset.id,
        url: result.url,
        width: result.width,
        height: result.height,
      },
    });
  } catch (error: any) {
    if (error.message === "Unauthorized") {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
    }
    console.error("Upload error:", error);
    return NextResponse.json(
      { error: "Upload failed" },
      { status: 500 }
    );
  }
}
