import { NextRequest, NextResponse } from "next/server";
import { z } from "zod";
import { requireSession } from "@/lib/auth";
import { generateDishDescription } from "@/lib/ai";

const describeSchema = z.object({
  name: z.string().min(1),
  category: z.string().min(1),
  ingredients: z.array(z.string()).optional(),
  cuisine: z.string().optional(),
  language: z.enum(["en", "ar"]).default("en"),
});

export async function POST(request: NextRequest) {
  try {
    await requireSession();
    const body = await request.json();
    const data = describeSchema.parse(body);

    const description = await generateDishDescription({
      name: data.name,
      category: data.category,
      ingredients: data.ingredients,
      cuisine: data.cuisine,
      language: data.language,
    });

    return NextResponse.json({ description });
  } catch (error: any) {
    if (error instanceof z.ZodError) {
      return NextResponse.json(
        { error: "Validation failed", details: error.errors },
        { status: 400 }
      );
    }
    if (error.message === "Unauthorized") {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
    }
    console.error("AI describe error:", error);
    return NextResponse.json(
      { error: "Failed to generate description" },
      { status: 500 }
    );
  }
}
