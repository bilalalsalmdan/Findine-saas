import { NextRequest, NextResponse } from "next/server";
import { z } from "zod";
import { db } from "@/lib/db";
import { users, restaurants, subscriptions, menus } from "@/db/schema";
import { eq } from "drizzle-orm";
import {
  hashPassword,
  createAccessToken,
  createRefreshToken,
  setAuthCookies,
} from "@/lib/auth";
import { slugify } from "@/lib/utils";

const registerSchema = z.object({
  name: z.string().min(2).max(255),
  email: z.string().email(),
  password: z.string().min(8),
  restaurantName: z.string().min(2).max(255),
  phone: z.string().optional(),
  country: z.string().default("JO"),
});

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const data = registerSchema.parse(body);

    // Check if email exists
    const [existing] = await db
      .select({ id: users.id })
      .from(users)
      .where(eq(users.email, data.email.toLowerCase()))
      .limit(1);

    if (existing) {
      return NextResponse.json(
        { error: "Email already registered" },
        { status: 409 }
      );
    }

    // Generate unique slug
    let slug = slugify(data.restaurantName);
    const [existingSlug] = await db
      .select({ id: restaurants.id })
      .from(restaurants)
      .where(eq(restaurants.slug, slug))
      .limit(1);
    if (existingSlug) {
      slug = `${slug}-${Date.now().toString(36)}`;
    }

    // Create restaurant
    const [restaurant] = await db
      .insert(restaurants)
      .values({
        name: data.restaurantName,
        slug,
        country: data.country,
        currency: data.country === "JO" ? "JOD" : "USD",
        email: data.email,
        phone: data.phone,
      })
      .returning();

    // Create default menu
    await db.insert(menus).values({
      restaurantId: restaurant.id,
      name: "Main Menu",
      nameAr: "القائمة الرئيسية",
      isDefault: true,
    });

    // Create user
    const passwordHash = await hashPassword(data.password);
    const [user] = await db
      .insert(users)
      .values({
        email: data.email.toLowerCase(),
        passwordHash,
        name: data.name,
        phone: data.phone,
        role: "restaurant_owner",
        restaurantId: restaurant.id,
      })
      .returning();

    // Create trial subscription
    await db.insert(subscriptions).values({
      restaurantId: restaurant.id,
      plan: "base",
      status: "trialing",
      trialEnd: new Date(Date.now() + 14 * 24 * 60 * 60 * 1000), // 14-day trial
    });

    // Generate tokens
    const payload = {
      sub: user.id,
      email: user.email,
      role: user.role,
      restaurantId: restaurant.id,
      name: user.name,
    };

    const accessToken = await createAccessToken(payload);
    const refreshToken = await createRefreshToken(payload);

    await setAuthCookies(accessToken, refreshToken);

    return NextResponse.json(
      {
        user: {
          id: user.id,
          email: user.email,
          name: user.name,
          role: user.role,
          restaurantId: restaurant.id,
        },
        restaurant: {
          id: restaurant.id,
          name: restaurant.name,
          slug: restaurant.slug,
        },
        token: accessToken,
      },
      { status: 201 }
    );
  } catch (error) {
    if (error instanceof z.ZodError) {
      return NextResponse.json(
        { error: "Validation failed", details: error.errors },
        { status: 400 }
      );
    }
    console.error("Register error:", error);
    return NextResponse.json(
      { error: "Internal server error" },
      { status: 500 }
    );
  }
}
