import type { Metadata } from "next";
import "@/styles/globals.css";

export const metadata: Metadata = {
  title: {
    default: "Jeelah Menu | Digital Menu & Restaurant Management Platform",
    template: "%s | Jeelah Menu",
  },
  description:
    "Transform your restaurant with AI-powered digital menus, QR ordering, and smart analytics. Trusted by 1000+ restaurants across MENA.",
  keywords: [
    "digital menu",
    "QR menu",
    "restaurant management",
    "قائمة رقمية",
    "مطعم",
    "AI menu",
    "restaurant POS",
  ],
  authors: [{ name: "Jeelah Menu" }],
  creator: "Jeelah Menu",
  openGraph: {
    type: "website",
    locale: "en_US",
    alternateLocale: "ar_SA",
    url: "https://jeelahmenu.com",
    siteName: "Jeelah Menu",
    title: "Jeelah Menu | Digital Menu & Restaurant Management",
    description:
      "AI-powered digital menus and restaurant management for MENA.",
    images: [{ url: "/images/og-image.png", width: 1200, height: 630 }],
  },
  twitter: {
    card: "summary_large_image",
    title: "Jeelah Menu",
    description:
      "AI-powered digital menus and restaurant management for MENA.",
  },
  robots: {
    index: true,
    follow: true,
    googleBot: {
      index: true,
      follow: true,
      "max-video-preview": -1,
      "max-image-preview": "large",
      "max-snippet": -1,
    },
  },
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="en" dir="ltr" className="scroll-smooth">
      <head>
        <link rel="preconnect" href="https://fonts.googleapis.com" />
        <link
          rel="preconnect"
          href="https://fonts.gstatic.com"
          crossOrigin="anonymous"
        />
        <link
          href="https://fonts.googleapis.com/css2?family=DM+Sans:ital,opsz,wght@0,9..40,100..1000;1,9..40,100..1000&family=Playfair+Display:ital,wght@0,400..900;1,400..900&display=swap"
          rel="stylesheet"
        />
      </head>
      <body className="font-sans antialiased">{children}</body>
    </html>
  );
}
