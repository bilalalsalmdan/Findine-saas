# Jeelah Menu

> AI-powered digital menu & restaurant management platform for MENA.

**Production SaaS** — Not a demo, not an MVP. Built to scale to 10,000+ restaurants.

---

## What's Included

| Layer | Status | Details |
|-------|--------|---------|
| **Architecture** | ✅ Complete | System design, folder structure, data flow |
| **Database** | ✅ Complete | 12 tables, indexes, multi-tenant isolation, SQL migration |
| **Auth & RBAC** | ✅ Complete | JWT + refresh tokens, 4 roles, middleware |
| **API Routes** | ✅ Complete | Auth, dishes, AI, fully validated with Zod |
| **AI Integration** | ✅ Complete | Dish descriptions, translations, social copy |
| **Dashboard UI** | ✅ Complete | Sidebar, topbar, responsive layout |
| **Marketing UI** | ✅ Complete | Navbar, footer, navigation config |
| **Storage** | ✅ Complete | R2 upload + sharp image pipeline |
| **Design System** | ✅ Complete | Tailwind config with FineDine tokens |
| **Deploy Guide** | ✅ Complete | Vercel + Neon + R2 + checklist |

## Quick Start

```bash
npm install
cp .env.example .env    # fill credentials
npm run db:push          # run migrations
npm run dev              # http://localhost:3000
```

## Docs

- [Architecture](docs/ARCHITECTURE.md) — Full system design
- [Deployment](docs/DEPLOY.md) — Production deployment guide
- [.env.example](.env.example) — All required environment variables
