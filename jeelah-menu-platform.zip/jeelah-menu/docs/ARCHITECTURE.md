# Jeelah Menu — System Architecture

> Production-ready SaaS platform for restaurant digital menus, ordering, and management.
> Modeled after FineDine Menu. Localized for Arabic-first markets.

---

## 1. System Overview

```
┌──────────────────────────────────────────────────────────────┐
│                        CLIENTS                                │
│  Marketing Site ← → Restaurant Dashboard ← → Public Menu     │
│  (SSR/SSG)          (Client Components)     (SSR + ISR)       │
└──────────────────────┬───────────────────────────────────────┘
                       │ HTTPS
┌──────────────────────▼───────────────────────────────────────┐
│                   NEXT.JS 14 (App Router)                     │
│  ┌─────────┐  ┌──────────┐  ┌──────────┐  ┌──────────────┐  │
│  │ Server  │  │  API     │  │  Auth    │  │ Middleware   │  │
│  │ Comps   │  │  Routes  │  │ (NextAuth│  │ (tenant,     │  │
│  │         │  │  /api/*  │  │  + JWT)  │  │  RBAC, i18n) │  │
│  └────┬────┘  └────┬─────┘  └────┬─────┘  └──────┬───────┘  │
│       │            │             │                │           │
│  ┌────▼────────────▼─────────────▼────────────────▼───────┐  │
│  │              SERVICE LAYER (lib/services/*)             │  │
│  │  MenuService │ DishService │ OrderService │ AIService   │  │
│  └────────────────────────┬───────────────────────────────┘  │
│                           │                                   │
│  ┌────────────────────────▼───────────────────────────────┐  │
│  │              DATA LAYER (Drizzle ORM)                   │  │
│  │  db/schema/* → PostgreSQL (Neon)                        │  │
│  └────────────────────────────────────────────────────────┘  │
└──────────────────────────────────────────────────────────────┘
                       │
        ┌──────────────┼──────────────┐
        ▼              ▼              ▼
   ┌─────────┐  ┌───────────┐  ┌──────────┐
   │ Neon    │  │Cloudflare │  │ Claude   │
   │ Postgres│  │ R2/Images │  │ API (AI) │
   └─────────┘  └───────────┘  └──────────┘
```

---

## 2. Tech Stack

| Layer | Technology | Rationale |
|-------|-----------|-----------|
| Framework | Next.js 14 (App Router) | SSR, SSG, ISR, API routes, middleware — single deployable |
| UI | React 18 + Tailwind CSS | Server Components default, client only when needed |
| ORM | Drizzle ORM | Type-safe, zero overhead, SQL-like |
| Database | PostgreSQL 15 (Neon) | Serverless Postgres, branching, connection pooling |
| Auth | NextAuth.js v5 + JWT | Session management, refresh tokens, OAuth-ready |
| Storage | Cloudflare R2 | S3-compatible, zero egress fees |
| AI | Anthropic Claude API | Dish descriptions, translations, social media copy |
| Payments | Stripe + Moyasar | International + MENA payment rails |
| Deploy | Vercel | Edge functions, automatic preview deploys |
| Email | Resend | Transactional emails |
| Analytics | PostHog (self-hosted) | Product analytics, feature flags |

---

## 3. Folder Structure

```
jeelah-menu/
├── docs/
│   ├── ARCHITECTURE.md          ← You are here
│   ├── DATABASE.md              ← Schema documentation
│   ├── API.md                   ← API contract
│   └── DEPLOY.md                ← Deployment guide
│
├── src/
│   ├── app/
│   │   ├── (marketing)/         ← Marketing pages (SSG)
│   │   │   ├── layout.tsx       ← Navbar + Footer
│   │   │   ├── page.tsx         ← Homepage
│   │   │   ├── pricing/
│   │   │   ├── solutions/
│   │   │   ├── features/
│   │   │   ├── about/
│   │   │   ├── contact/
│   │   │   ├── blog/
│   │   │   │   └── [slug]/
│   │   │   ├── enterprise/
│   │   │   └── legal/
│   │   │       └── [slug]/
│   │   │
│   │   ├── (dashboard)/         ← Protected dashboard
│   │   │   ├── layout.tsx       ← Sidebar + Topbar
│   │   │   ├── admin/           ← Super admin pages
│   │   │   │   ├── restaurants/
│   │   │   │   ├── plans/
│   │   │   │   ├── analytics/
│   │   │   │   └── settings/
│   │   │   └── restaurant/      ← Restaurant owner pages
│   │   │       ├── menu/
│   │   │       │   └── [menuId]/
│   │   │       ├── dishes/
│   │   │       │   └── [dishId]/
│   │   │       ├── categories/
│   │   │       ├── qr/
│   │   │       ├── orders/
│   │   │       ├── analytics/
│   │   │       ├── staff/
│   │   │       ├── settings/
│   │   │       ├── billing/
│   │   │       └── integrations/
│   │   │
│   │   ├── (auth)/              ← Auth pages
│   │   │   ├── layout.tsx
│   │   │   ├── login/
│   │   │   ├── register/
│   │   │   └── forgot-password/
│   │   │
│   │   ├── menu/                ← Public menu (customer-facing)
│   │   │   └── [slug]/          ← /menu/restaurant-name
│   │   │       ├── page.tsx     ← Menu display
│   │   │       └── [dishId]/    ← Dish detail modal
│   │   │
│   │   ├── api/                 ← API routes
│   │   │   ├── auth/
│   │   │   ├── restaurants/
│   │   │   ├── menus/
│   │   │   ├── dishes/
│   │   │   ├── categories/
│   │   │   ├── orders/
│   │   │   ├── analytics/
│   │   │   ├── upload/
│   │   │   ├── ai/
│   │   │   ├── qr/
│   │   │   └── webhooks/
│   │   │
│   │   ├── layout.tsx           ← Root layout
│   │   └── globals.css
│   │
│   ├── components/
│   │   ├── ui/                  ← Design system primitives
│   │   │   ├── button.tsx
│   │   │   ├── input.tsx
│   │   │   ├── card.tsx
│   │   │   ├── badge.tsx
│   │   │   ├── modal.tsx
│   │   │   ├── tabs.tsx
│   │   │   ├── dropdown.tsx
│   │   │   ├── toggle.tsx
│   │   │   ├── toast.tsx
│   │   │   ├── avatar.tsx
│   │   │   ├── skeleton.tsx
│   │   │   └── data-table.tsx
│   │   │
│   │   ├── marketing/           ← Landing page components
│   │   │   ├── navbar.tsx
│   │   │   ├── footer.tsx
│   │   │   ├── hero.tsx
│   │   │   ├── logo-cloud.tsx
│   │   │   ├── feature-row.tsx
│   │   │   ├── pricing-cards.tsx
│   │   │   ├── testimonials.tsx
│   │   │   └── cta-section.tsx
│   │   │
│   │   ├── dashboard/           ← Dashboard components
│   │   │   ├── sidebar.tsx
│   │   │   ├── topbar.tsx
│   │   │   ├── stats-grid.tsx
│   │   │   ├── menu-editor.tsx
│   │   │   ├── dish-form.tsx
│   │   │   ├── category-list.tsx
│   │   │   ├── order-table.tsx
│   │   │   ├── qr-generator.tsx
│   │   │   ├── analytics-charts.tsx
│   │   │   └── staff-manager.tsx
│   │   │
│   │   └── menu/                ← Public menu components
│   │       ├── menu-header.tsx
│   │       ├── category-nav.tsx
│   │       ├── dish-card.tsx
│   │       ├── dish-detail.tsx
│   │       ├── allergen-badge.tsx
│   │       ├── cart-drawer.tsx
│   │       └── language-switcher.tsx
│   │
│   ├── lib/
│   │   ├── auth.ts              ← NextAuth config
│   │   ├── db.ts                ← Drizzle client
│   │   ├── r2.ts                ← Cloudflare R2 client
│   │   ├── ai.ts                ← Claude API wrapper
│   │   ├── payments.ts          ← Stripe/Moyasar
│   │   ├── email.ts             ← Resend client
│   │   ├── qr.ts                ← QR code generation
│   │   ├── utils.ts             ← Shared utilities
│   │   ├── validations.ts       ← Zod schemas
│   │   └── services/
│   │       ├── restaurant.ts
│   │       ├── menu.ts
│   │       ├── dish.ts
│   │       ├── order.ts
│   │       ├── category.ts
│   │       ├── analytics.ts
│   │       └── subscription.ts
│   │
│   ├── db/
│   │   ├── schema/
│   │   │   ├── restaurants.ts
│   │   │   ├── users.ts
│   │   │   ├── menus.ts
│   │   │   ├── categories.ts
│   │   │   ├── dishes.ts
│   │   │   ├── orders.ts
│   │   │   ├── subscriptions.ts
│   │   │   ├── analytics.ts
│   │   │   └── assets.ts
│   │   ├── migrations/
│   │   └── seed/
│   │       └── index.ts
│   │
│   ├── config/
│   │   ├── site.ts              ← Site metadata
│   │   ├── plans.ts             ← Subscription plans
│   │   ├── navigation.ts        ← Nav items
│   │   └── i18n.ts              ← Locale config
│   │
│   ├── hooks/
│   │   ├── use-restaurant.ts
│   │   ├── use-menu.ts
│   │   ├── use-cart.ts
│   │   └── use-analytics.ts
│   │
│   ├── types/
│   │   └── index.ts
│   │
│   └── styles/
│       └── globals.css
│
├── public/
│   ├── images/
│   └── fonts/
│
├── .env.example
├── drizzle.config.ts
├── middleware.ts
├── next.config.ts
├── tailwind.config.ts
├── tsconfig.json
├── package.json
└── README.md
```

---

## 4. Design Tokens

Extracted from FineDine forensics, rebranded for Jeelah:

```
Brand Primary:     #E6034B (pink-red)
Brand Violet:      #7C3AED
Brand Gradient:    linear-gradient(135deg, #E6034B, #7C3AED)

Gray Scale:
  50:  #F9FAFB
  100: #F3F4F6
  200: #E5E7EB
  300: #D1D5DB
  400: #9CA3AF
  500: #6B7280
  600: #4B5563
  700: #374151
  800: #1F2937
  900: #111827
  950: #030712

Fonts:
  UI:      'DM Sans', sans-serif
  Display: 'Playfair Display', serif

Radius:
  sm:   0.375rem
  md:   0.5rem
  lg:   0.75rem
  xl:   1.25rem
  pill: 9999px

Spacing (4px base grid):
  Section padding: 96px (24 × 4px)
  Card padding:    32px (8 × 4px)
  Component gap:   16px (4 × 4px)

Shadows:
  sm:  0 1px 2px rgba(0,0,0,.05)
  md:  0 4px 6px -1px rgba(0,0,0,.07), 0 2px 4px -2px rgba(0,0,0,.05)
  lg:  0 10px 15px -3px rgba(0,0,0,.08), 0 4px 6px -4px rgba(0,0,0,.03)
  xl:  0 20px 25px -5px rgba(0,0,0,.08), 0 8px 10px -6px rgba(0,0,0,.03)
```

---

## 5. Page Inventory (58 pages)

### Marketing (28 pages)
| # | Route | Rendering | Notes |
|---|-------|-----------|-------|
| 1 | `/` | SSG | Homepage — 14 sections |
| 2 | `/pricing` | SSG | 3 tiers + toggle |
| 3 | `/solutions` | SSG | Use-case overview |
| 4 | `/solutions/qr-menu` | SSG | QR menu feature |
| 5 | `/solutions/tablet-menu` | SSG | Tablet feature |
| 6 | `/solutions/ordering` | SSG | Ordering feature |
| 7 | `/solutions/payments` | SSG | Payment feature |
| 8 | `/features` | SSG | Full feature grid |
| 9 | `/features/ai-menu` | SSG | AI menu builder |
| 10 | `/features/ai-website` | SSG | AI website builder |
| 11 | `/features/analytics` | SSG | Analytics feature |
| 12 | `/features/reservations` | SSG | Reservations |
| 13 | `/enterprise` | SSG | Enterprise landing |
| 14 | `/about` | SSG | Company page |
| 15 | `/contact` | SSG | Contact form |
| 16 | `/blog` | ISR | Blog index |
| 17 | `/blog/[slug]` | ISR | Blog posts |
| 18-22 | `/legal/[slug]` | SSG | Terms, Privacy, DPA, Cookies, Acceptable Use |
| 23-28 | Language variants | SSG | /ar, /en, /tr, /fr, /es, /de |

### Customer Menu (8 pages)
| # | Route | Rendering |
|---|-------|-----------|
| 29 | `/menu/[slug]` | ISR (60s) | Menu display |
| 30 | `/menu/[slug]/[dishId]` | ISR | Dish detail |
| 31 | `/menu/[slug]/cart` | Client | Cart/order |
| 32 | `/menu/[slug]/checkout` | Client | Payment |
| 33 | `/menu/[slug]/order/[id]` | SSR | Order status |
| 34 | `/menu/[slug]/feedback` | Client | Feedback form |
| 35 | `/menu/[slug]/allergens` | ISR | Allergen matrix |
| 36 | `/menu/[slug]/search` | Client | Search dishes |

### Dashboard (22 pages)
| # | Route | Auth |
|---|-------|------|
| 37 | `/restaurant/` | Owner | Dashboard home |
| 38 | `/restaurant/menu` | Owner | Menu list |
| 39 | `/restaurant/menu/[menuId]` | Owner | Menu editor |
| 40 | `/restaurant/dishes` | Owner | Dish list |
| 41 | `/restaurant/dishes/[dishId]` | Owner | Dish editor |
| 42 | `/restaurant/dishes/new` | Owner | Create dish |
| 43 | `/restaurant/categories` | Owner | Category manager |
| 44 | `/restaurant/qr` | Owner | QR code generator |
| 45 | `/restaurant/orders` | Owner | Order list |
| 46 | `/restaurant/orders/[id]` | Owner | Order detail |
| 47 | `/restaurant/analytics` | Owner | Analytics dashboard |
| 48 | `/restaurant/staff` | Owner | Staff management |
| 49 | `/restaurant/settings` | Owner | Restaurant settings |
| 50 | `/restaurant/billing` | Owner | Subscription/billing |
| 51 | `/restaurant/integrations` | Owner | POS integrations |
| 52 | `/admin/` | Admin | System dashboard |
| 53 | `/admin/restaurants` | Admin | All restaurants |
| 54 | `/admin/restaurants/[id]` | Admin | Restaurant detail |
| 55 | `/admin/plans` | Admin | Plan management |
| 56 | `/admin/analytics` | Admin | System analytics |
| 57 | `/admin/settings` | Admin | System config |
| 58 | `/admin/users` | Admin | User management |

---

## 6. Component Inventory (42 components)

### Design System (12)
Button, Input, Card, Badge, Modal, Tabs, Dropdown, Toggle, Toast, Avatar, Skeleton, DataTable

### Marketing (8)
Navbar, Footer, Hero, LogoCloud, FeatureRow, PricingCards, Testimonials, CTASection

### Dashboard (12)
Sidebar, Topbar, StatsGrid, MenuEditor, DishForm, CategoryList, OrderTable, QRGenerator, AnalyticsCharts, StaffManager, BillingCard, IntegrationCard

### Menu (10)
MenuHeader, CategoryNav, DishCard, DishDetail, AllergenBadge, CartDrawer, LanguageSwitcher, NutritionInfo, FeedbackForm, OrderTracker

---

## 7. Auth & RBAC

### Roles
| Role | Access |
|------|--------|
| `super_admin` | Everything. System settings, all restaurants. |
| `restaurant_owner` | Own restaurant dashboard. Billing. Staff. |
| `restaurant_staff` | Orders, menu viewing. Limited by owner config. |
| `customer` | Public menu, ordering, feedback. |

### Auth Flow
```
Login → NextAuth → JWT (15min) + Refresh Token (30d)
       → Middleware checks role + tenant_id
       → API routes enforce row-level isolation
```

### Middleware Chain
```
1. i18n detection (Accept-Language + cookie)
2. Auth check (JWT validation)
3. RBAC enforcement (role → route mapping)
4. Tenant isolation (restaurant_id injection)
5. Rate limiting (per-tenant)
```

---

## 8. Multi-Tenancy Model

**Strategy: Shared database, row-level isolation**

Every query includes `WHERE restaurant_id = ?` enforced at the service layer via a `withTenant()` wrapper.

```typescript
// Every service method receives tenant context
export function withTenant<T>(
  restaurantId: string,
  fn: (ctx: TenantContext) => Promise<T>
): Promise<T> {
  return fn({ restaurantId });
}

// Usage
const dishes = await withTenant(user.restaurantId, (ctx) =>
  db.select().from(dishes).where(eq(dishes.restaurantId, ctx.restaurantId))
);
```

---

## 9. API Contract Summary

| Method | Endpoint | Auth | Description |
|--------|----------|------|-------------|
| POST | `/api/auth/register` | Public | Create account |
| POST | `/api/auth/login` | Public | Login |
| POST | `/api/auth/refresh` | Refresh | Refresh JWT |
| GET | `/api/restaurants` | Admin | List restaurants |
| POST | `/api/restaurants` | Admin | Create restaurant |
| GET | `/api/restaurants/[id]` | Owner | Get restaurant |
| PATCH | `/api/restaurants/[id]` | Owner | Update restaurant |
| GET | `/api/menus` | Owner | List menus |
| POST | `/api/menus` | Owner | Create menu |
| GET | `/api/menus/[id]` | Owner | Get menu |
| PATCH | `/api/menus/[id]` | Owner | Update menu |
| DELETE | `/api/menus/[id]` | Owner | Delete menu |
| GET | `/api/dishes` | Owner | List dishes |
| POST | `/api/dishes` | Owner | Create dish |
| GET | `/api/dishes/[id]` | Owner | Get dish |
| PATCH | `/api/dishes/[id]` | Owner | Update dish |
| DELETE | `/api/dishes/[id]` | Owner | Delete dish |
| GET | `/api/categories` | Owner | List categories |
| POST | `/api/categories` | Owner | Create category |
| PATCH | `/api/categories/[id]` | Owner | Update/reorder |
| DELETE | `/api/categories/[id]` | Owner | Delete category |
| GET | `/api/orders` | Owner | List orders |
| POST | `/api/orders` | Customer | Place order |
| PATCH | `/api/orders/[id]` | Owner | Update status |
| GET | `/api/analytics` | Owner | Get analytics |
| POST | `/api/upload` | Owner | Upload image |
| POST | `/api/ai/describe` | Owner | AI dish description |
| POST | `/api/ai/translate` | Owner | AI translation |
| POST | `/api/qr` | Owner | Generate QR code |
| POST | `/api/webhooks/stripe` | System | Stripe webhook |
| POST | `/api/webhooks/moyasar` | System | Moyasar webhook |

---

## 10. Deployment Architecture

```
Vercel (Frontend + API)
  ├── Edge Middleware (auth, i18n, tenant)
  ├── Serverless Functions (API routes)
  └── Static/ISR pages (marketing, menus)

Neon (Database)
  ├── Production branch
  ├── Preview branches (per PR)
  └── Connection pooling via @neondatabase/serverless

Cloudflare R2 (Storage)
  ├── /restaurants/{id}/logo.*
  ├── /restaurants/{id}/dishes/{dishId}.*
  └── /restaurants/{id}/gallery/*

Claude API (AI)
  └── On-demand: descriptions, translations, social copy
```

**Monthly Cost @ 100 restaurants:**
| Service | Cost |
|---------|------|
| Vercel Pro | $20 |
| Neon Pro | $19 |
| Cloudflare R2 | ~$5 |
| Claude API | ~$10 |
| Resend | $0 (free tier) |
| **Total** | **~$54/mo** |
