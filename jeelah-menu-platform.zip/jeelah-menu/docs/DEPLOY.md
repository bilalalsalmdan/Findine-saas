# Deployment Guide

## Prerequisites

- Node.js 18+
- PostgreSQL 15+ (or Neon account)
- Cloudflare R2 bucket
- Anthropic API key
- Stripe account (optional for billing)
- Vercel account (recommended)

---

## 1. Local Development Setup

```bash
# Clone and install
git clone https://github.com/YOUR_ORG/jeelah-menu.git
cd jeelah-menu
npm install

# Configure environment
cp .env.example .env
# Edit .env with your credentials

# Run database migration
npm run db:push

# Seed demo data (optional)
npm run db:seed

# Start dev server
npm run dev
```

Visit `http://localhost:3000`

---

## 2. Database Setup (Neon)

1. Create account at [neon.tech](https://neon.tech)
2. Create a new project → copy connection string
3. Add to `.env`: `DATABASE_URL=postgresql://...`
4. Run migrations:

```bash
npm run db:push
```

---

## 3. Cloudflare R2 Setup

1. Go to Cloudflare Dashboard → R2
2. Create bucket: `jeelah-menu`
3. Create R2 API token (Object Read & Write)
4. Enable public access (or use custom domain)
5. Add to `.env`:

```
R2_ENDPOINT=https://ACCOUNT_ID.r2.cloudflarestorage.com
R2_ACCESS_KEY_ID=...
R2_SECRET_ACCESS_KEY=...
R2_BUCKET_NAME=jeelah-menu
R2_PUBLIC_URL=https://assets.yourdomain.com
```

---

## 4. Deploy to Vercel

```bash
# Install Vercel CLI
npm i -g vercel

# Deploy
vercel

# Set environment variables
vercel env add DATABASE_URL
vercel env add JWT_SECRET
# ... add all from .env.example
```

Or connect your GitHub repo in the Vercel dashboard for automatic deployments.

### Vercel Configuration

- **Framework**: Next.js
- **Build Command**: `npm run build`
- **Output Directory**: `.next`
- **Node.js Version**: 18.x

---

## 5. Production Checklist

### Security
- [ ] JWT_SECRET is 32+ random characters
- [ ] All API routes validate auth
- [ ] CORS configured for your domains only
- [ ] Rate limiting enabled (middleware)
- [ ] SQL injection prevented (Drizzle parameterizes)
- [ ] XSS prevented (React escapes by default)
- [ ] HTTPS enforced
- [ ] Sensitive env vars not exposed to client

### Performance
- [ ] Images optimized (sharp + WebP)
- [ ] Static pages pre-rendered (SSG)
- [ ] Menu pages use ISR (60s revalidation)
- [ ] Database queries indexed
- [ ] CDN configured for R2 assets
- [ ] Font preloaded

### Monitoring
- [ ] Error tracking (Sentry recommended)
- [ ] Uptime monitoring
- [ ] Database connection pooling
- [ ] Log aggregation

### Business
- [ ] Stripe webhooks configured
- [ ] Transactional emails working
- [ ] Backup strategy for database
- [ ] GDPR/data privacy compliance
- [ ] Terms of service published
- [ ] Support email configured

---

## 6. Scaling to 10,000+ Restaurants

| Concern | Solution |
|---------|----------|
| Database | Neon autoscales; add read replicas if needed |
| API | Vercel serverless functions scale automatically |
| Storage | R2 has no egress fees; unlimited scale |
| AI | Claude API handles concurrent requests well |
| Search | Add Meilisearch or Typesense for dish search |
| Real-time | Add Pusher/Ably for order notifications |
| Cache | Add Redis (Upstash) for hot paths |
| CDN | Cloudflare in front of everything |

**Estimated monthly costs at 10,000 restaurants:**

| Service | Cost |
|---------|------|
| Vercel Pro | $20-100 |
| Neon Scale | $69-200 |
| R2 | ~$50 |
| Claude API | ~$200 |
| Total | ~$350-550/mo |

Revenue at 10k restaurants × $39/mo average = **$390,000/mo MRR**.
Infrastructure cost is < 0.2% of revenue.
